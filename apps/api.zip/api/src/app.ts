import crypto from 'node:crypto';
import cors from 'cors';
import express from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import { pinoHttp } from 'pino-http';
import { env } from './config/env.js';
import { errorHandler, notFound } from './middleware/error-handler.js';
import { logger } from './lib/logger.js';
import { apiRouter } from './routes/index.js';
export const app = express();
app.disable('x-powered-by');
app.use((req, res, next) => { req.id = req.header('x-request-id') ?? crypto.randomUUID(); res.setHeader('x-request-id', req.id); next(); });
app.use(pinoHttp({ logger, genReqId: (req: express.Request) => req.id }));
app.use(helmet());
app.use(cors({ origin: env.ALLOWED_ORIGINS.split(',').map((item) => item.trim()), credentials: false }));
if (env.NODE_ENV === 'production') {
  app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-8', legacyHeaders: false }));
}
app.use(express.json({ limit: '1mb' }));
app.use('/api', apiRouter);
app.use(notFound);
app.use(errorHandler);
