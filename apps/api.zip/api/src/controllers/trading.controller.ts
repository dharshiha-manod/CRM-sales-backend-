import type { RequestHandler } from 'express';
import { AppError } from '../errors/app-error.js';
import { tradingService } from '../services/trading.service.js';
import type { TradingResource } from '../lib/trading-resources.js';
import { actorFromAuth } from '../lib/trade-verification.js';

type Req = Parameters<RequestHandler>[0];
type Res = Parameters<RequestHandler>[1];

const org = (req: Parameters<RequestHandler>[0]) => {
  const value = req.header('x-organization-id');
  if (!value) throw new AppError(400, 'ORGANIZATION_CONTEXT_REQUIRED', 'x-organization-id is required');
  return value;
};

const idParam = (value: string | string[] | undefined) => {
  const result = Array.isArray(value) ? value[0] : value;
  if (!result) throw new AppError(400, 'INVALID_ID', 'A resource id is required');
  return result;
};

function assertRequiredFields(resource: TradingResource, body: Record<string, unknown>) {
  const missing = resource.requiredFields.filter((key) => body[key] === undefined || body[key] === null || body[key] === '');
  if (missing.length > 0) throw new AppError(400, 'VALIDATION_ERROR', `${missing.join(', ')} ${missing.length > 1 ? 'are' : 'is'} required.`);
}

function asBody(req: Parameters<RequestHandler>[0]): Record<string, unknown> {
  const body = req.body;
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new AppError(400, 'VALIDATION_ERROR', 'A JSON object body is required.');
  return body as Record<string, unknown>;
}


// NEW
export const trading = {
  list: (resource: TradingResource): RequestHandler => async (req, res) => {
    const requested = typeof req.query.industryTypeId === 'string' ? req.query.industryTypeId : undefined;
    res.json({ data: await tradingService.list(resource, org(req), req.industryScope!, requested) });
  },
  get: (resource: TradingResource): RequestHandler => async (req, res) => {
    res.json({ data: await tradingService.get(resource, org(req), idParam(req.params.id), req.industryScope!) });
  },
  create: (resource: TradingResource): RequestHandler => async (req, res) => {
    const body = asBody(req);
    assertRequiredFields(resource, body);
    res.status(201).json({ data: await tradingService.create(resource, org(req), body, req.industryScope!) });
  },
  update: (resource: TradingResource): RequestHandler => async (req, res) => {
    const body = asBody(req);
    res.json({ data: await tradingService.update(resource, org(req), idParam(req.params.id), body, req.industryScope!) });
  },
  remove: (resource: TradingResource): RequestHandler => async (req, res) => {
    res.json({ data: await tradingService.remove(resource, org(req), idParam(req.params.id), req.industryScope!) });
  },
  sendPurchaseEnquiry: async (req: Req, res: Res) => {
    res.json({ data: await tradingService.sendPurchaseEnquiry(org(req), idParam(req.params.id), req.industryScope!) });
  },
  // Submit / approve / reject a trade document (records who did it; see lib/trade-verification.ts).
  reviewDocument: async (req: Req, res: Res) => {
    const body = asBody(req);
    const action = String(body.action ?? '');
    if (!['submit', 'approve', 'reject'].includes(action)) throw new AppError(400, 'VALIDATION_ERROR', 'action must be submit, approve or reject.');
    const actor = actorFromAuth((req.auth ?? {}) as Record<string, unknown>, req.organizationRole ?? '');
    res.json({ data: await tradingService.reviewDocument(org(req), idParam(req.params.id), action, body, req.industryScope!, actor) });
  },
   sendShipmentDocuments: async (req: Req, res: Res) => {
    res.json({ data: await tradingService.sendShipmentDocuments(org(req), idParam(req.params.id), req.body ?? {}, req.industryScope!) });
  },
  sendCustomerInvoice: async (req: Req, res: Res) => {
    res.json({ data: await tradingService.sendCustomerInvoice(org(req), idParam(req.params.id), req.body ?? {}, req.industryScope!) });
  },
};