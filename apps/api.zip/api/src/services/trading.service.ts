// NEW
// NEW
import * as repository from '../repositories/trading.repository.js';

export const tradingService = {
  list: repository.listTradingRecords,
  get: repository.getTradingRecord,
  create: repository.createTradingRecord,
  update: repository.updateTradingRecord,
  remove: repository.deleteTradingRecord,
  sendPurchaseEnquiry: repository.sendPurchaseEnquiry,
  sendShipmentDocuments: repository.sendShipmentDocuments,
   sendCustomerInvoice: repository.sendCustomerInvoice,
  reviewDocument: repository.reviewTradeDocument,
};