import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter } from 'expo-router';
import { ActivityIndicator, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { api } from '../lib/api';
import { accuracyLevel, formatDistance } from '../lib/geo';
import { getCurrentLocation, type GpsReading } from '../lib/location';
import { ensureWorkDayStarted, isTrackingRunning, setActiveVisitId } from '../lib/tracking';
import { AppButton } from './AppButton';
import { ProductPickerModal, type CatalogCartItem, type PendingProductRequest } from './ProductPickerModal';
import { QtyStepper } from './QtyStepper';

const PING_INTERVAL_MS = 120000;

export type AssignedClient = {
  id: string;
  client_code: string;
  client_name: string;
  city?: string | null;
  latitude?: number | null;
  longitude?: number | null;
};
type Visit = {
  id: string;
  status: 'checked_in' | 'in_progress' | 'checked_out';
  client_id: string | null;
  unlisted_client_name?: string | null;
  check_in_time: string;
  check_in_distance_meters?: number | null;
  check_in_within_geofence?: boolean | null;
  clients?: { client_name?: string } | null;
};

const OUTCOMES = [
  { value: 'sale_made', label: 'Sale made' },
  { value: 'follow_up_needed', label: 'Follow-up needed' },
  { value: 'no_interest', label: 'No interest' },
  { value: 'other', label: 'Other' },
];

const elapsed = (sinceIso: string) => {
  const minutes = Math.max(0, Math.floor((Date.now() - new Date(sinceIso).getTime()) / 60000));
  return minutes < 60 ? `${minutes}m` : `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
};

const lowAccuracyMessage = (location: GpsReading) =>
  location.accuracyMeters != null && accuracyLevel(location.accuracyMeters) === 'low'
    ? `GPS accuracy is too low (+/-${Math.round(location.accuracyMeters)}m). Move to an open area and try again.`
    : null;

export function FieldVisitPanel({ clients, refreshKey = 0, onChanged }: { clients: AssignedClient[]; refreshKey?: number; onChanged?: () => void }) {
  const router = useRouter();
  const [visits, setVisits] = useState<Visit[]>([]);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [notes, setNotes] = useState('');
  const [outcome, setOutcome] = useState('follow_up_needed');
  const [cart, setCart] = useState<CatalogCartItem[]>([]);
  const [pendingRequests, setPendingRequests] = useState<PendingProductRequest[]>([]);
  const [pickerVisible, setPickerVisible] = useState(false);
  const [, forceTick] = useState(0);
  const pingTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const activeVisit = visits.find((visit) => visit.status !== 'checked_out') ?? null;
  const activeVisitId = activeVisit?.id;

  const loadVisits = useCallback(async () => {
    try {
      const result = await api<{ data: Visit[] }>('/field-visits/mine');
      setVisits(result.data ?? []);
    } catch (cause) {
      setError((cause as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  // Loads on mount and again every time the home screen is pulled to refresh.
  useEffect(() => { void loadVisits(); }, [loadVisits, refreshKey]);

  // Re-render every 30s so the "elapsed" time stays current.
  useEffect(() => {
    if (!activeVisitId) return;
    const id = setInterval(() => forceTick((current) => current + 1), 30000);
    return () => clearInterval(id);
  }, [activeVisitId]);

  // Location ping while a visit is active.
  useEffect(() => {
    if (!activeVisitId) {
      if (pingTimer.current) { clearInterval(pingTimer.current); pingTimer.current = null; }
      return;
    }
      const ping = async () => {
      try {
        // The work-day tracker already records points (tagged with this visit). Ping here only as a fallback.
        if (await isTrackingRunning()) return;
        const location = await getCurrentLocation();
        await api(`/field-visits/${activeVisitId}/pings`, { method: 'POST', body: { location } });
      } catch { /* A background ping is non-blocking. */ }
    };
    void ping();
    pingTimer.current = setInterval(() => void ping(), PING_INTERVAL_MS);
    return () => {
      if (pingTimer.current) { clearInterval(pingTimer.current); pingTimer.current = null; }
    };
  }, [activeVisitId]);

   useEffect(() => {
    if (pendingRequests.length > 0) setOutcome('follow_up_needed');
  }, [pendingRequests.length]);

  // Tell the tracker which visit is open so each GPS point is tagged with it.
  useEffect(() => {
    void setActiveVisitId(activeVisitId ?? null);
  }, [activeVisitId]);

  function openClientMap(client: AssignedClient) {
    if (client.latitude == null || client.longitude == null) return;
    router.push({ pathname: '/client-map', params: { clientName: client.client_name, latitude: String(client.latitude), longitude: String(client.longitude) } } as never);
  }

  function addProduct(product: { id: string; product_name: string }) {
    setCart((current) => current.some((item) => item.productId === product.id) ? current : [...current, { productId: product.id, name: product.product_name, quantity: 1 }]);
  }

  function changeCartQuantity(productId: string, quantity: number) {
    setCart((current) => current.map((item) => item.productId === productId ? { ...item, quantity } : item));
  }

  async function checkIn(clientId: string) {
    setWorking(clientId);
    setMessage('');
    setError('');
    try {
      const location = await getCurrentLocation();
      const tooLow = lowAccuracyMessage(location);
      if (tooLow) { setError(tooLow); return; }
      const result = await api<{ data: Visit }>('/field-visits/check-in', { method: 'POST', body: { clientId, location } });
          setVisits((current) => [result.data, ...current]);
      void ensureWorkDayStarted(location);
      setMessage('Checked in successfully.');
      onChanged?.();
    } catch (cause) {
      setError((cause as Error).message);
    } finally {
      setWorking(null);
    }
  }

  async function checkOut() {
    if (!activeVisit) return;
    setWorking(activeVisit.id);
    setMessage('');
    setError('');
    // What has already been saved in this attempt. If check-out then fails, a retry
    // must NOT send the order / requirements again, so each list is cleared as soon as it is saved.
    let saved = '';
    try {
      const location = await getCurrentLocation();
      const tooLow = lowAccuracyMessage(location);
      if (tooLow) { setError(tooLow); return; }

      if (cart.length > 0) {
        await api(`/field-visits/${activeVisit.id}/orders`, { method: 'POST', body: { items: cart.map(({ productId, quantity }) => ({ productId, quantity })) } });
        setCart([]);
        saved += 'Order saved. ';
      }

      if (pendingRequests.length > 0) {
        if (!activeVisit.client_id) throw new Error('Unlisted product requests need a client linked to this visit.');
        await api('/requirements', {
          method: 'POST',
          body: {
            clientId: activeVisit.client_id,
            visitId: activeVisit.id,
            title: `Visit requirements - ${activeVisit.clients?.client_name ?? activeVisit.unlisted_client_name ?? 'client'}`,
            urgency: 'normal',
            items: pendingRequests.map(({ freeTextItem, quantity, notes: requestNotes }) => ({ freeTextItem, quantity, notes: requestNotes })),
          },
        });
        setPendingRequests([]);
        saved += 'Requirements saved. ';
      }

      const result = await api<{ data: Visit }>(`/field-visits/${activeVisit.id}/check-out`, { method: 'PATCH', body: { location, notes: notes || null, outcome } });
      setVisits((current) => current.map((visit) => visit.id === result.data.id ? result.data : visit));
      setNotes('');
      setMessage('Checked out successfully.');
      onChanged?.();
    } catch (cause) {
      setError(`${saved}${(cause as Error).message}`);
    } finally {
      setWorking(null);
    }
  }

  if (loading) return <ActivityIndicator style={styles.loading} />;

  return (
    <View style={styles.container}>
      {message ? <Text style={styles.success}>{message}</Text> : null}
      {error ? <Text style={styles.error}>{error}</Text> : null}
      {activeVisit ? (
        <View style={styles.activeCard}>
          <Text style={styles.activeTitle}>Checked in - {activeVisit.clients?.client_name ?? activeVisit.unlisted_client_name ?? 'Unlisted client'}</Text>
          <Text style={styles.activeMeta}>Since {new Date(activeVisit.check_in_time).toLocaleTimeString()} · {elapsed(activeVisit.check_in_time)} elapsed</Text>
          {activeVisit.check_in_within_geofence === false ? <Text style={styles.warning}>Check-in was outside the client&apos;s verification radius.</Text> : null}
          {activeVisit.check_in_within_geofence ? <Text style={styles.verified}>Location verified at check-in</Text> : null}
          {activeVisit.check_in_distance_meters != null ? (
            <Text style={activeVisit.check_in_within_geofence ? styles.verified : styles.warning}>{formatDistance(activeVisit.check_in_distance_meters)} from the client at check-in.</Text>
          ) : null}

          <View style={styles.productsSection}>
            <View style={styles.sectionHeader}>
              <Text style={styles.label}>Products</Text>
              <AppButton title="+ Add product" variant="secondary" onPress={() => setPickerVisible(true)} />
            </View>
            {cart.map((item) => (
              <View key={item.productId} style={styles.cartRow}>
                <Text style={styles.itemName}>{item.name}</Text>
                <QtyStepper value={item.quantity} onChange={(quantity) => changeCartQuantity(item.productId, quantity)} />
                <TouchableOpacity accessibilityRole="button" accessibilityLabel={`Remove ${item.name}`} onPress={() => setCart((current) => current.filter((entry) => entry.productId !== item.productId))} style={styles.remove}>
                  <Text style={styles.removeText}>X</Text>
                </TouchableOpacity>
              </View>
            ))}
            {pendingRequests.length > 0 ? (
              <View style={styles.pendingList}>
                <Text style={styles.pendingHeading}>Pending - needs review</Text>
                {pendingRequests.map((item, index) => (
                  <View key={`${item.freeTextItem}-${index}`} style={styles.pendingRow}>
                    <View style={styles.pendingText}>
                      <Text style={styles.itemName}>{item.freeTextItem}</Text>
                      <Text style={styles.pendingMeta}>Qty {item.quantity}{item.notes ? ` · ${item.notes}` : ''}</Text>
                    </View>
                    <TouchableOpacity accessibilityRole="button" accessibilityLabel={`Remove ${item.freeTextItem}`} onPress={() => setPendingRequests((current) => current.filter((_, entryIndex) => entryIndex !== index))} style={styles.remove}>
                      <Text style={styles.removeText}>X</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            ) : null}
          </View>

          <Text style={styles.label}>Outcome</Text>
          <View style={styles.outcomeRow}>
            {OUTCOMES.map((item) => (
              <TouchableOpacity key={item.value} style={[styles.outcomeChip, outcome === item.value && styles.outcomeChipActive]} onPress={() => setOutcome(item.value)}>
                <Text style={[styles.outcomeChipText, outcome === item.value && styles.outcomeChipTextActive]}>{item.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          {pendingRequests.length > 0 ? <Text style={styles.outcomeHelper}>Auto-set: {pendingRequests.length} requested item{pendingRequests.length === 1 ? '' : 's'} need follow-up.</Text> : null}
          <TextInput style={styles.input} value={notes} onChangeText={setNotes} placeholder="Visit notes (optional)" multiline />
          <AppButton title="Check out" loading={working === activeVisit.id} disabled={working === activeVisit.id} onPress={() => void checkOut()} />
          <ProductPickerModal
            visible={pickerVisible}
            cart={cart}
            onClose={() => setPickerVisible(false)}
            onAddProduct={addProduct}
            onQuantityChange={changeCartQuantity}
            onAddRequest={(request) => setPendingRequests((current) => [...current, request])}
          />
        </View>
      ) : (
        <>
          <Text style={styles.sectionTitle}>Check in at a client</Text>
          {clients.length === 0 ? (
            <Text style={styles.empty}>No active client assignments yet - ask your admin to assign clients to you.</Text>
          ) : clients.map((client) => (
            <View key={client.id} style={styles.clientRow}>
              <View style={styles.clientDetails}>
                <Text style={styles.clientName}>{client.client_name}</Text>
                <Text style={styles.clientMeta}>{client.client_code}{client.city ? ` · ${client.city}` : ''}</Text>
                {client.latitude == null || client.longitude == null ? <Text style={styles.gpsNotSet}>GPS location not set</Text> : null}
              </View>
              <View style={styles.clientActions}>
                <AppButton
                  title={client.latitude != null && client.longitude != null ? 'View on map' : 'Location not set'}
                  variant="secondary"
                  onPress={() => openClientMap(client)}
                  disabled={working !== null || client.latitude == null || client.longitude == null}
                />
                <AppButton title="Check in" loading={working === client.id} disabled={working !== null} onPress={() => void checkIn(client.id)} />
              </View>
            </View>
          ))}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  loading: { marginVertical: 20 },
  container: { gap: 10 },
  sectionTitle: { color: '#0f172a', fontSize: 18, fontWeight: '700', marginBottom: 4 },
  empty: { color: '#64748b' },
  success: { color: '#15803d', marginBottom: 4 },
  error: { color: '#b91c1c', marginBottom: 4 },
  clientRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', padding: 16, borderRadius: 10, gap: 12 },
  clientDetails: { flex: 1 },
  clientActions: { gap: 8 },
  clientName: { color: '#0f172a', fontSize: 16, fontWeight: '700' },
  clientMeta: { color: '#64748b', marginTop: 2 },
  gpsNotSet: { color: '#b45309', fontSize: 12, marginTop: 4 },
  activeCard: { backgroundColor: '#fff', padding: 16, borderRadius: 12, gap: 10, borderWidth: 2, borderColor: '#16a34a' },
  activeTitle: { color: '#0f172a', fontSize: 18, fontWeight: '700' },
  activeMeta: { color: '#64748b' },
  verified: { color: '#15803d', fontWeight: '600' },
  warning: { color: '#b45309', fontWeight: '600' },
  productsSection: { backgroundColor: '#f8fafc', borderRadius: 10, padding: 12, gap: 10 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 10 },
  label: { color: '#0f172a', fontWeight: '700', marginTop: 2 },
  cartRow: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#fff', borderRadius: 8, padding: 10 },
  itemName: { color: '#0f172a', fontWeight: '600', flex: 1 },
  remove: { height: 36, width: 36, alignItems: 'center', justifyContent: 'center', borderRadius: 18, backgroundColor: '#fee2e2' },
  removeText: { color: '#b91c1c', fontWeight: '700' },
  pendingList: { borderLeftWidth: 4, borderLeftColor: '#b45309', backgroundColor: '#fffbeb', padding: 10, borderRadius: 8, gap: 8 },
  pendingHeading: { color: '#92400e', fontWeight: '700', fontSize: 13 },
  pendingRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  pendingText: { flex: 1, gap: 2 },
  pendingMeta: { color: '#92400e', fontSize: 12 },
  outcomeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  outcomeChip: { paddingVertical: 7, paddingHorizontal: 12, borderRadius: 999, backgroundColor: '#f1f5f9' },
  outcomeChipActive: { backgroundColor: '#0f172a' },
  outcomeChipText: { color: '#334155', fontSize: 13 },
  outcomeChipTextActive: { color: '#fff' },
  outcomeHelper: { color: '#b45309', fontSize: 12, fontWeight: '600', marginTop: -4 },
  input: { borderWidth: 1, borderColor: '#cbd5e1', borderRadius: 8, padding: 10, minHeight: 60, textAlignVertical: 'top' },
});