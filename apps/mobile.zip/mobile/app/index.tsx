import { useCallback, useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { useRouter } from 'expo-router';
import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { FieldVisitPanel } from '../src/components/FieldVisitPanel';
import { AppButton } from '../src/components/AppButton';
import { SignInScreen } from '../src/components/SignInScreen';
import { api } from '../src/lib/api';
import { supabase } from '../src/lib/supabase';

type Client = {
  id: string;
  client_code: string;
  client_name: string;
  client_type: string;
  phone?: string | null;
  city?: string | null;
  priority: string;
  latitude?: number | null;
  longitude?: number | null;
};
type Dashboard = {
  representative: { employee_code: string; user_profiles?: { display_name?: string | null } | null };
  summary: { assignedClients: number; scheduledVisits: number; pendingCollections: number; upcomingFollowUps: number };
  clients: Client[];
};

export default function HomeScreen() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    setError('');
    try {
      const response = await api<{ data: Dashboard }>('/mobile/dashboard');
      setDashboard(response.data);
    } catch (cause) {
      setError((cause as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  const refreshSession = useCallback(async () => {
    const { data } = await supabase.auth.getSession();
    setSession(data.session);
    setLoading(false);
    if (data.session) await refresh();
  }, [refresh]);

  useEffect(() => {
    void refreshSession();
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      if (nextSession) void refresh();
      else setDashboard(null);
    });
    return () => listener.subscription.unsubscribe();
  }, [refresh, refreshSession]);

  function openClientMap(client: Client) {
    if (client.latitude == null || client.longitude == null) return;
    router.push({
      pathname: '/client-map',
      params: {
        clientName: client.client_name,
        latitude: String(client.latitude),
        longitude: String(client.longitude),
      },
    } as never);
  }

  if (loading) return <SafeAreaView style={styles.center}><ActivityIndicator size="large" /></SafeAreaView>;
  if (!session) return <SignInScreen onSignedIn={refreshSession} />;

  const summary = dashboard?.summary;
  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <FlatList
        data={dashboard?.clients ?? []}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={() => { setLoading(true); void refresh(); }} />}
        ListHeaderComponent={(
          <>
            <View style={styles.header}>
              <View>
                <Text style={styles.title}>Good morning, {dashboard?.representative.user_profiles?.display_name ?? 'Representative'}</Text>
                <Text style={styles.subtitle}>{dashboard?.representative.employee_code}</Text>
              </View>
              <AppButton title="Sign out" variant="ghost" onPress={() => void supabase.auth.signOut()} />
            </View>
            <View style={styles.cards}>
              <Metric label="Assigned clients" value={summary?.assignedClients ?? 0} />
              <Metric label="Visits today" value={summary?.scheduledVisits ?? 0} />
              <Metric label="Collections" value={summary?.pendingCollections ?? 0} />
              <Metric label="Follow-ups" value={summary?.upcomingFollowUps ?? 0} />
            </View>
            <FieldVisitPanel clients={dashboard?.clients ?? []} />
            <Text style={styles.sectionTitle}>Assigned clients</Text>
            {error ? <Text style={styles.error}>{error}</Text> : null}
          </>
        )}
        renderItem={({ item }) => (
          <View style={styles.client}>
            <View style={styles.clientHeading}>
              <Text style={styles.clientName}>{item.client_name}</Text>
              <AppButton
                title={item.latitude != null && item.longitude != null ? 'View on map' : 'Location not set'}
                variant="secondary"
                onPress={() => openClientMap(item)}
                disabled={item.latitude == null || item.longitude == null}
              />
            </View>
            <Text>{item.client_type} · {item.city ?? 'Location not set'}</Text>
            <Text>{item.phone ?? 'No phone'} · {item.priority} priority</Text>
          </View>
        )}
        ListEmptyComponent={!error ? <Text style={styles.empty}>No active client assignments yet.</Text> : null}
        contentContainerStyle={styles.content}
      />
      <StatusBar style="auto" />
    </SafeAreaView>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return <View style={styles.metric}><Text style={styles.metricValue}>{value}</Text><Text style={styles.metricLabel}>{label}</Text></View>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  content: { padding: 18, gap: 10 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 },
  title: { fontSize: 24, fontWeight: '700' },
  subtitle: { color: '#64748b', marginTop: 3 },
  cards: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  metric: { width: '47%', backgroundColor: '#fff', padding: 16, borderRadius: 10 },
  metricValue: { fontSize: 24, fontWeight: '700' },
  metricLabel: { color: '#475569', marginTop: 3 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 4 },
  client: { backgroundColor: '#fff', padding: 16, borderRadius: 10, gap: 4 },
  clientHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  clientName: { fontSize: 16, fontWeight: '700' },
  empty: { color: '#64748b' },
  error: { color: '#b91c1c', marginBottom: 10 },
});
