import { useEffect, useState } from 'react';
import { PharmaDrugSchedulePage } from './components/PharmaDrugSchedulePage';
import type { ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { useCurrentMembership } from './auth/useCurrentMembership';
import { CallsPage } from './components/CallsPage';
import { IncomingCallPopup } from './components/IncomingCallPopup'; // NEW
import { ClientsPage } from './components/ClientsPage';
import { CollectionsPage } from './components/CollectionsPage';
import { DashboardPage } from './components/DashboardPage';
import { FieldActivityPage } from './components/FieldActivityPage';
import { FollowUpsPage } from './components/FollowUpsPage';
import { LeadsPage } from './components/leadpage';
import { OrdersPage } from './components/OrdersPage';
import { ProductsPage } from './components/ProductsPage';
import { BrandsCategoriesPage } from './components/BrandsCategoriesPage';
import { QuotationsPage } from './components/QuotationsPage';
import { TargetsPage } from './components/TargetsPage';
import { InventoryPage } from './components/InventoryPage';
import { RequirementsPage } from './components/RequirementsPage';
import { RepresentativesPage } from './components/RepresentativesPage';
import { RouteBeatPage } from './components/RouteBeatPage';
import { SchemeDiscountPage } from './components/SchemeDiscountPage';
import { FmcgDistributorPage } from './components/FmcgDistributorPage';
import { SchoolManagementPage } from './components/SchoolManagementPage';
import { SchoolSalesCollectionPage } from './components/SchoolSalesCollectionPage';
import { AcademicYearTermPage } from './components/AcademicYearTermPage';
import { SpecificPricingDiscountPage } from './components/SpecificPricingDiscountPage'; 
import { SalesReturnDamagePage } from './components/SalesReturnDamagePage';
import { BatchExpiryPage } from './components/BatchExpiryPage';
import { FmcgCurrencyRatesPage } from './components/FmcgCurrencyRatesPage';
import { FmcgShipmentsPage } from './components/FmcgShipmentsPage';
import { FabricRollPage } from './components/FabricRollPage';
import { TextileSamplePage } from './components/TextileSamplePage';
import { TextileAutomationPage } from './components/TextileAutomationPage';
import { TextileSupplierPaymentsPage } from './components/TextileSupplierPaymentsPage';
import { TextileCreditNotesPage } from './components/TextileCreditNotesPage';
import { TextileReturnsRefundsPage } from './components/TextileReturnsRefundsPage';
import { TextileInvoicesPage } from './components/Textileinvoicepages';
import { QualityInspectionPage } from './components/QualityInspectionPage';

import { TextileSuppliersPage, TextilePurchaseOrdersPage, TextileGrnPage } from './components/TextilePurchasePages';
import { PharmaBatchExpiryPage } from './components/PharmaBatchExpiryPage';
import { PharmaSamplePage } from './components/PharmaSamplePage';
import { PharmaProductPromotionPage } from './components/PharmaProductPromotionPage';
import { PharmaHospitalEngagementPage } from './components/PharmaHospitalEngagementPage';
import { PharmaMedicineReturnPage } from './components/PharmaMedicineReturnPage';
import { PharmaRefundsPage } from './components/PharmaRefundsPage';
import { PharmaRecallPage } from './components/PharmaRecallPage';
import { PharmaCompanyPage, PharmaSuppliersPage, PharmaPurchaseOrdersPage, PharmaGrnPage, PharmaPurchaseReturnsPage, PharmaSupplierPaymentsPage, PharmaInvoicesPage, PharmaScanPage, PharmaReportsPage, PharmaStockLedgerPage, PharmaOutstandingPage } from './components/PharmaDistributorPages';
import { PharmaAutomationPage } from './components/PharmaAutomationPage';
import { TradingDealPage } from './components/TradingDealPage';
import { TradingSupplierVendorPage } from './components/TradingSupplierVendorPage';
import { TradingPurchaseEnquiryPage } from './components/TradingPurchaseEnquiryPage';
import { TradingPriceRateListPage } from './components/TradingPriceRateListPage';
import { TradingShipmentPage } from './components/TradingShipmentPage';
import { TradingSalesOrderPage } from './components/TradingSalesOrderPage';
import { TradeDocumentsPage } from './components/TradeDocumentsPage';   
import { CurrencyManagementPage } from './components/CurrencyManagementPage';
import { LogisticsPage } from './components/LogisticsPage';
import { ShipmentChargesPage } from './components/ShipmentChargesPage';
import { CustomerInvoicesPage } from './components/CustomerInvoicesPage';
import { ImportExportPage } from './components/ImportExportPage';
import { CustomsClearancePage } from './components/CustomsClearancePage';
import { ClaimsDisputesPage } from './components/ClaimsDisputesPage';
import { CommissionManagementPage } from './components/CommissionManagementPage';
import { CommissionRulesPage } from './components/CommissionRulesPage';
import { TradeProfitabilityPage } from './components/TradeProfitabilityPage';
import { TradeCompliancePage } from './components/TradeCompliancePage';
import { TradeFinanceLCPage } from './components/TradeFinanceLCPage';
import { VehicleDealerPage } from './components/VehicleDealerPage';
import { VehicleInsightsPage } from './components/VehicleInsightsPage';
import { VehicleCatalogPage } from './components/VehicleCatalogPage';
import { VehicleTestDrivePage } from './components/VehicleTestDrivePage';
import { VehicleBookingPage } from './components/VehicleBookingPage';
import { VehicleSchemeDiscountPage } from './components/VehicleSchemeDiscountPage';
import { VehicleDeliveryPdiPage } from './components/VehicleDeliveryPdiPage';
import { VehicleRegistrationPage } from './components/VehicleRegistrationPage';
import { VehicleFinanceLoanPage } from './components/VehicleFinanceLoanPage';
import { VehicleInsurancePage } from './components/VehicleInsurancePage';
import { VehicleExchangePage } from './components/VehicleExchangePage';
import { VehicleWarrantyPage } from './components/VehicleWarrantyPage';
import { VehicleServicePage } from './components/VehicleServicePage';
import { VehicleReturnsPage } from './components/VehicleReturnsPage';
import { VehicleInvoicePage } from './components/VehicleInvoicePage';
import { ReportsPage } from './components/ReportsPage';
import { SignInForm } from './components/SignInForm';
import { UsersPage } from './components/UsersPage';
import { SettingsPage } from './components/SettingsPage';
import { NotificationsPage, useUnreadNotificationCount } from './components/NotificationsPage';
import { GpsTrackingPage } from './components/GpsTrackingPage';
import { PublicQuotationPage } from './components/PublicQuotationPage';
import { supabase } from './lib/supabase';
import { INDUSTRY_MODULES } from './industry/moduleDefs';
import type { ModuleDef } from './industry/moduleDefs';
import { IndustryModulePage } from './industry/IndustryModulePage';
import { INDUSTRY_CONFIGS } from './industry/mockData';
import type { IndustryKey } from './industry/types';
import { useIndustry, INDUSTRY_ORDER } from './industry/IndustryContext';
import './sidebar-layout.css';
type Page = 'dashboard' | 'clients' | 'representatives' | 'users' | 'leads' | 'fieldActivity' | 'products' | 'brandsCategories' | 'requirements' | 'quotations' | 'orders' | 'collections' | 'followUps' | 'calls' | 'reports' | 'target' | 'inventory' | 'gpsTracking' | 'settings' | 'notifications' | `industry:${string}`;
const labels: Record<string, string> = { dashboard: 'Sales overview', clients: 'Clients', representatives: 'Sales representatives', users: 'User management', leads: 'Leads', fieldActivity: 'Field activity', products: 'Products', requirements: 'Requirements', quotations: 'Quotations', orders: 'Sales orders', collections: 'Collections', followUps: 'Follow-ups', calls: 'Calls & IVR', reports: 'Reports', target: 'Target', inventory: 'Inventory', gpsTracking: 'GPS Verified Tracking', settings: 'Settings', notifications: 'Notification' };

function moduleLabel(key: IndustryKey, moduleId: string): string {
  const mod = INDUSTRY_MODULES[key].find((m) => m.id === moduleId);
  return mod ? mod.label : 'Industry module';
}

export default function App() {
  const publicToken = window.location.pathname.match(/^\/quote\/([^/]+)$/)?.[1];
  if (publicToken) return <PublicQuotationPage token={publicToken} />;
  const [reportsOpen, setReportsOpen] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  const [loadingSession, setLoadingSession] = useState(Boolean(supabase));
   const validPages: string[] = ['dashboard', 'clients', 'representatives', 'users', 'leads', 'fieldActivity', 'products', 'brandsCategories', 'requirements', 'quotations', 'orders', 'collections', 'followUps', 'calls', 'reports', 'target', 'inventory', 'gpsTracking', 'settings', 'notifications'];
  const pageFromHash = (): Page => {
    const hash = window.location.hash.replace('#', '');
    if (hash.startsWith('industry:')) return hash as Page;
    return validPages.includes(hash) ? (hash as Page) : 'dashboard';
  };
  const [page, setPage] = useState<Page>(pageFromHash());
const { activeIndustry, setActiveIndustry, canSwitchIndustry } = useIndustry();
const { isGlobal } = useCurrentMembership();
  const unreadNotificationCount = useUnreadNotificationCount();
  async function refreshSession() { if (!supabase) return; const { data } = await supabase.auth.getSession(); setSession(data.session); setLoadingSession(false); }
  useEffect(() => { if (!supabase) return; void refreshSession(); const { data } = supabase.auth.onAuthStateChange((_event, next) => { setSession(next); setLoadingSession(false); }); return () => data.subscription.unsubscribe(); }, []);
  useEffect(() => { window.location.hash = page; }, [page]);
  useEffect(() => { const onHashChange = () => setPage(pageFromHash()); window.addEventListener('hashchange', onHashChange); return () => window.removeEventListener('hashchange', onHashChange); }, []);
  async function signOut() { if (!supabase) return; await supabase.auth.signOut(); setSession(null); }
  if (!supabase) return <main><h1>Field Sales Platform</h1><p>Configuration required: add the Supabase browser settings.</p></main>;
  if (loadingSession) return <main><h1>Field Sales Platform</h1><p>Checking session…</p></main>;
  if (!session) return <main><h1>Field Sales Platform</h1><p>Sales operations workspace</p><SignInForm client={supabase} onSignedIn={refreshSession} /></main>;
     const content: Record<string, ReactNode> = { dashboard: <DashboardPage />, clients: <ClientsPage />, representatives: <RepresentativesPage />, users: <UsersPage />, leads: <LeadsPage />, fieldActivity: <FieldActivityPage />, products: <ProductsPage />, brandsCategories: <BrandsCategoriesPage />, requirements: <RequirementsPage />, quotations: <QuotationsPage />, orders: <OrdersPage />, collections: <CollectionsPage />, followUps: <FollowUpsPage />, calls: <CallsPage />, reports: <ReportsPage />, target: <TargetsPage />, inventory: <InventoryPage />, gpsTracking: <GpsTrackingPage />, settings: <SettingsPage />, notifications: <NotificationsPage onNavigate={(target) => setPage(target as Page)} /> };
  INDUSTRY_ORDER.forEach((key) => {
    INDUSTRY_MODULES[key].forEach((mod: ModuleDef) => {
      content[`industry:${key}:${mod.id}`] = <IndustryModulePage industryLabel={INDUSTRY_CONFIGS[key].label} module={mod} />;
    });
  });
  content['industry:fmcg:route-beat'] = <RouteBeatPage />;
  content['industry:fmcg:shipment'] = <FmcgShipmentsPage />;
  content['industry:fmcg:scheme-discount'] = <SchemeDiscountPage />;
   content['industry:fmcg:distributor'] = <FmcgDistributorPage />;
  content['industry:fmcg:sales-return-damage'] = <SalesReturnDamagePage />;
   content['industry:fmcg:batch-expiry'] = <BatchExpiryPage />;
  content['industry:fmcg:currency-rates'] = <FmcgCurrencyRatesPage />;
  content['industry:fmcg:trade-documents'] = <TradeDocumentsPage />;
  content['industry:fmcg:import-export'] = <ImportExportPage />;
  content['industry:fmcg:customs-clearance'] = <CustomsClearancePage />;
  content['industry:fmcg:shipment-charges'] = <ShipmentChargesPage />;
  content['industry:fmcg:customer-invoices'] = <CustomerInvoicesPage />;
content['industry:school:school-management'] = <SchoolManagementPage />;
    content['industry:school:school-sales-collection'] = <SchoolSalesCollectionPage />;
  content['industry:school:academic-year-term'] = <AcademicYearTermPage />;
  content['industry:school:specific-pricing-discount'] = <SpecificPricingDiscountPage />;
  
   content['industry:textile:automation'] = <TextileAutomationPage />;
  content['industry:textile:supplier-payments'] = <TextileSupplierPaymentsPage />;
  content['industry:textile:credit-notes'] = <TextileCreditNotesPage />;
  content['industry:textile:returns-refunds'] = <TextileReturnsRefundsPage />;
  content['industry:textile:suppliers'] = <TextileSuppliersPage />;
  content['industry:textile:purchase-orders'] = <TextilePurchaseOrdersPage />;
  content['industry:textile:goods-receipt'] = <TextileGrnPage />;
  content['industry:textile:fabric-roll'] = <FabricRollPage />;
  content['industry:textile:textile-sample'] = <TextileSamplePage />;
  content['industry:textile:quality-inspection'] = <QualityInspectionPage />;
  content['industry:textile:invoices'] = <TextileInvoicesPage />;
  content['industry:pharma:batch-expiry'] = <PharmaBatchExpiryPage />;
  content['industry:pharma:medicine-return'] = <PharmaMedicineReturnPage />;
  content['industry:pharma:refunds'] = <PharmaRefundsPage />;
  content['industry:pharma:recall'] = <PharmaRecallPage />;
  content['industry:pharma:drug-schedule'] = <PharmaDrugSchedulePage />;
  content['industry:pharma:samples'] = <PharmaSamplePage />;
  content['industry:pharma:promotions'] = <PharmaProductPromotionPage />;
  content['industry:pharma:hospital-engagement'] = <PharmaHospitalEngagementPage />;
  content['industry:pharma:company'] = <PharmaCompanyPage />;
  content['industry:pharma:supplier'] = <PharmaSuppliersPage />;
  content['industry:pharma:purchase-order'] = <PharmaPurchaseOrdersPage />;
  content['industry:pharma:grn'] = <PharmaGrnPage />;
  content['industry:pharma:automation'] = <PharmaAutomationPage />;
  content['industry:pharma:scan'] = <PharmaScanPage />;
  content['industry:pharma:gst-invoice'] = <PharmaInvoicesPage />;
  content['industry:pharma:purchase-return'] = <PharmaPurchaseReturnsPage />;
  content['industry:pharma:supplier-payment'] = <PharmaSupplierPaymentsPage />;
  for (const mod of INDUSTRY_MODULES.pharma) if (mod.group === 'reports') content[`industry:pharma:${mod.id}`] = <PharmaReportsPage kind={mod.id.replace('report-', '')} />;
  content['industry:pharma:stock-ledger'] = <PharmaStockLedgerPage />;
  content['industry:pharma:customer-outstanding'] = <PharmaOutstandingPage />;
  content['industry:trading:deal'] = <TradingDealPage />;
  content['industry:trading:supplier-vendor'] = <TradingSupplierVendorPage />;
  content['industry:trading:purchase-enquiry'] = <TradingPurchaseEnquiryPage />;
  content['industry:trading:price-rate-list'] = <TradingPriceRateListPage />;
  content['industry:trading:shipment'] = <TradingShipmentPage />;
  content['industry:trading:sales-order'] = <TradingSalesOrderPage />;
  content['industry:trading:trade-documents'] = <TradeDocumentsPage />;
  content['industry:trading:currency'] = <CurrencyManagementPage />;
  content['industry:trading:logistics'] = <LogisticsPage />;
  content['industry:trading:import-export'] = <ImportExportPage />;
  content['industry:trading:customs-clearance'] = <CustomsClearancePage />;
  content['industry:trading:claims-disputes'] = <ClaimsDisputesPage />;
   content['industry:trading:commission'] = <CommissionManagementPage />;
  content['industry:trading:commission-rules'] = <CommissionRulesPage />;
  content['industry:trading:trade-profitability'] = <TradeProfitabilityPage />;
  content['industry:trading:trade-compliance'] = <TradeCompliancePage />;
content['industry:trading:trade-finance-lc'] = <TradeFinanceLCPage />;
  content['industry:trading:shipment-charges'] = <ShipmentChargesPage />;
  content['industry:trading:customer-invoices'] = <CustomerInvoicesPage />;
  content['industry:vehicle:dealers'] = <VehicleDealerPage />;
  content['industry:vehicle:catalog'] = <VehicleCatalogPage />;
  content['industry:vehicle:test-drive'] = <VehicleTestDrivePage />;
  content['industry:vehicle:booking'] = <VehicleBookingPage />;
  content['industry:vehicle:schemes'] = <VehicleSchemeDiscountPage />;
  content['industry:vehicle:delivery-pdi'] = <VehicleDeliveryPdiPage />;
  content['industry:vehicle:registration'] = <VehicleRegistrationPage />;
  content['industry:vehicle:finance'] = <VehicleFinanceLoanPage />;
  content['industry:vehicle:insurance'] = <VehicleInsurancePage />;
  content['industry:vehicle:exchange'] = <VehicleExchangePage />;
  content['industry:vehicle:warranty'] = <VehicleWarrantyPage />;
  content['industry:vehicle:service'] = <VehicleServicePage />;
  content['industry:vehicle:returns'] = <VehicleReturnsPage />;
  content['industry:vehicle:invoices'] = <VehicleInvoicePage />;
  content['industry:vehicle:insights'] = <VehicleInsightsPage />;
  const isPharma = activeIndustry === 'pharma'; // Pharma Distributor / Wholesaler hides field-sales / rep menus (other industries unchanged)
   const pageBase = page.split(':').slice(0, 3).join(':');
  const item = (value: Page, text: string, icon: string) => (
    <button key={value} className={pageBase === value ? 'active' : ''} onClick={() => setPage(value)} title={text}>
      <span>{icon}</span>
      <span className="nav-label-text">{text}</span>
      {value === 'notifications' && unreadNotificationCount > 0 && <span className="notification-unread-dot" aria-label={`${unreadNotificationCount} unread notification${unreadNotificationCount === 1 ? '' : 's'}`} />}
    </button>
  );

  const pageLabel = page.startsWith('industry:')
    ? moduleLabel(activeIndustry, page.split(':')[2])
    : (labels[page] ?? 'Dashboard');

  return (
    <div className="app-shell">
      <IncomingCallPopup />{/* NEW — global, shows on any page when a call rings in */}
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">SC</span><span>Sales CRM<small>FIELD OPERATIONS</small></span></div>
        <nav className="side-nav" aria-label="Main navigation">
          <p className="nav-label">OVERVIEW</p>{item('dashboard', 'Dashboard', '▦')}{!isPharma && item('reports', 'Reports', '↗')}
          <p className="nav-label">PIPELINE</p>{item('leads', 'Leads', '✦')}{item('clients', isPharma ? 'Customers & Pharmacies' : 'Clients', '◎')}{item('requirements', 'Requirements', '⚑')}{item('quotations', 'Quotations', '≡')}
          <p className="nav-label">SALES OPERATIONS</p>{item('orders', 'Sales orders', '₹')}{item('collections', isPharma ? 'Collections & Outstanding' : 'Collections', '₹')}{item('followUps', 'Follow-ups', '◷')}{!isPharma && item('fieldActivity', 'Field activity', '⌖')}{!isPharma && item('gpsTracking', 'GPS Verified Tracking', '⦿')}
                  <p className="nav-label">PRODUCT &amp; INVENTORY</p>{item('products', 'Products', '▣')}{item('brandsCategories', 'Brands & Categories', '◆')}{item('inventory', 'Inventory', '▤')}
          {!isPharma && <p className="nav-label">TEAM &amp; PERFORMANCE</p>}{!isPharma && item('target', 'Target', '◎')}{!isPharma && item('representatives', 'Sales representatives', '♙')}
          <p className="nav-label">ADMINISTRATION</p>{item('users', 'User management', '♧')}{item('settings', 'Settings', '⚙')}{item('notifications', 'Notification', '⚑')}{!isPharma && item('calls', 'Calls & IVR', '☎')}
               <p className="nav-label">{INDUSTRY_CONFIGS[activeIndustry].label.toUpperCase()} MODULES</p>
          {INDUSTRY_MODULES[activeIndustry].filter((mod) => mod.group !== 'reports').map((mod) => item(`industry:${activeIndustry}:${mod.id}` as Page, mod.label, mod.icon))}
          {INDUSTRY_MODULES[activeIndustry].some((mod) => mod.group === 'reports') && (() => {
            const reps = INDUSTRY_MODULES[activeIndustry].filter((mod) => mod.group === 'reports');
            const onReport = reps.some((mod) => pageBase === `industry:${activeIndustry}:${mod.id}`);
            const open = reportsOpen || onReport;
            return (<>
              <button className={onReport ? 'active' : ''} onClick={() => setReportsOpen(!open)} title="Reports" aria-expanded={open}><span>📊</span><span className="nav-label-text">{INDUSTRY_CONFIGS[activeIndustry].label} Reports</span><span style={{ marginLeft: 'auto' }}>{open ? '▾' : '▸'}</span></button>
              {open && reps.map((mod) => { const v = `industry:${activeIndustry}:${mod.id}`; return <button key={v} className={pageBase === v ? 'active' : ''} style={{ paddingLeft: '1.6rem', fontSize: '.82rem' }} onClick={() => setPage(v as Page)} title={mod.label}><span aria-hidden>•</span><span className="nav-label-text">{mod.label}</span></button>; })}
            </>);
          })()}
        </nav>
        <div className="sidebar-footer"><span className="online-dot" />Secure organization workspace</div>
      </aside>
         <div className="workspace">
          <header className="topbar">
          {canSwitchIndustry ? (
            <select
              className="active-industry-badge active-industry-switch"
              data-industry={activeIndustry}
              aria-label="Switch industry type"
              value={activeIndustry}
              onChange={(e) => {
                const key = e.target.value as IndustryKey;
                setActiveIndustry(key);
                setPage(`industry:${key}:${INDUSTRY_MODULES[key][0].id}` as Page);
              }}
            >
              {INDUSTRY_ORDER.map((key) => <option key={key} value={key}>{INDUSTRY_CONFIGS[key].label}</option>)}
            </select>
          ) : (
            <span className="active-industry-badge" data-industry={activeIndustry}>{INDUSTRY_CONFIGS[activeIndustry].label}</span>
          )}
               <div className="account">
            <span>{session.user.email}</span>
            <button onClick={() => void signOut()}>Sign out</button>
          </div>
        </header>
<main className="content">{content[pageBase] ?? content.dashboard}</main>   </div>
    </div>
  );
}