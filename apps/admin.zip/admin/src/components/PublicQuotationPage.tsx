import { useEffect, useState } from 'react';

type Line = { quantity: number; unit_price: number; subtotal: number; products?: { product_name?: string } | null };
type Quote = { quotation_number: string; status: string; valid_until?: string | null; total_amount: number; clients?: { client_name?: string } | null; organizations?: { name?: string } | null; quotation_items?: Line[] };
const baseUrl = import.meta.env.VITE_API_URL ?? 'http://localhost:3000/api';
const money = (value: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(Number(value));

export function PublicQuotationPage({ token }: { token: string }) {
  const [quote, setQuote] = useState<Quote | null>(null); const [error, setError] = useState<string | null>(null); const [done, setDone] = useState(false); const [saving, setSaving] = useState(false);
  useEffect(() => { fetch(`${baseUrl}/public/quotations/${encodeURIComponent(token)}`).then(async (response) => { const body = await response.json(); if (!response.ok) throw new Error(body.error?.message ?? 'Quotation unavailable'); setQuote(body.data); }).catch((cause: unknown) => setError(cause instanceof Error ? cause.message : 'Quotation unavailable')); }, [token]);
  async function decide(decision: 'accepted' | 'rejected') { setSaving(true); try { const response = await fetch(`${baseUrl}/public/quotations/${encodeURIComponent(token)}/decision`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ decision }) }); const body = await response.json(); if (!response.ok) throw new Error(body.error?.message ?? 'Unable to record your response'); setQuote(body.data); setDone(true); } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to record your response'); } finally { setSaving(false); } }
  if (error) return <main className="public-quotation"><h1>Quotation unavailable</h1><p>{error}</p></main>;
  if (!quote) return <main className="public-quotation"><p>Loading quotation…</p></main>;
  if (done || quote.status !== 'sent') return <main className="public-quotation"><h1>Thank you</h1><p>Your response has been recorded — our team will follow up shortly.</p><p>Current status: {quote.status.replace('_', ' ')}.</p></main>;
  return <main className="public-quotation"><header><p>{quote.organizations?.name ?? 'Sales CRM'}</p><h1>Quotation {quote.quotation_number}</h1><p>Prepared for {quote.clients?.client_name ?? 'you'}</p></header><table><thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr></thead><tbody>{quote.quotation_items?.map((line, index) => <tr key={index}><td>{line.products?.product_name ?? 'Product'}</td><td>{line.quantity}</td><td>{money(line.unit_price)}</td><td>{money(line.subtotal)}</td></tr>)}</tbody></table><h2>Total: {money(quote.total_amount)}</h2>{quote.valid_until && <p>Valid until {quote.valid_until}</p>}<div><button disabled={saving} onClick={() => void decide('accepted')}>Accept Quotation</button><button disabled={saving} onClick={() => void decide('rejected')}>Reject Quotation</button></div></main>;
}
