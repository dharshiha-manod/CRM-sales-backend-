// "Send documents": emails a shipment's VERIFIED documents (Commercial Invoice, Packing List, Bill of Lading ...)
// to the customer. Leave the address empty to use the email saved on the customer; type one to send somewhere else
// (the customer's bank, the shipping line ...). Only Verified documents are ever sent - the server enforces it.
import { useState } from 'react';
import { api } from '../lib/api';

type SendResult = { sent_to: string[]; documents: string[] };

export function SendShipmentDocumentsButton({ shipment }: { shipment: Record<string, unknown> }) {
  const [open, setOpen] = useState(false);
  const [to, setTo] = useState('');
  const [note, setNote] = useState('');
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [isError, setIsError] = useState(false);
  const [sentOnce, setSentOnce] = useState(false);

  const send = async () => {
    setSending(true);
    setMessage(null);
    try {
      const res = await api<{ data: SendResult }>(`/trading/shipments/${String(shipment.id)}/send-documents`, {
        method: 'POST',
        body: JSON.stringify({ to: to.trim(), message: note.trim() }),
      });
      setMessage(`Sent ${res.data.documents.length} document(s) to ${res.data.sent_to.join(', ')}.`);
      setIsError(false);
      setSentOnce(true);
      setOpen(false);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Could not send the documents.');
      setIsError(true);
    } finally {
      setSending(false);
    }
  };

  const box = { padding: '0.45rem 0.6rem', border: '1px solid var(--line)', borderRadius: 8, font: 'inherit', background: 'transparent', minWidth: 0, width: '100%' } as const;

  return (
    <span style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start', gap: 6, maxWidth: 420 }}>
      <button type="button" className="quiet-button" onClick={() => { setOpen((v) => !v); setMessage(null); }}>
        {sentOnce ? 'Send documents again' : 'Send documents'}
      </button>
      {open && (
        <span style={{ display: 'grid', gap: 6, width: '100%', padding: 10, border: '1px solid #e2e8f0', borderRadius: 10, background: '#f8fafc' }}>
          <label style={{ display: 'grid', gap: 3, fontSize: 12, fontWeight: 600 }}>
            Send to (email)
            <input style={box} type="text" value={to} onChange={(e) => setTo(e.target.value)} placeholder="Leave empty to use the customer's saved email" />
          </label>
          <label style={{ display: 'grid', gap: 3, fontSize: 12, fontWeight: 600 }}>
            Message (optional)
            <textarea style={{ ...box, minHeight: 56 }} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Please find the shipping documents attached" />
          </label>
          <small style={{ color: '#64748b' }}>Only Verified documents are sent, as download links.</small>
          <span style={{ display: 'inline-flex', gap: 8 }}>
            <button type="button" className="primary-action" disabled={sending} onClick={() => void send()}>{sending ? 'Sending…' : 'Send now'}</button>
            <button type="button" className="quiet-button" disabled={sending} onClick={() => setOpen(false)}>Cancel</button>
          </span>
        </span>
      )}
      {message && <span style={{ fontSize: 12, lineHeight: 1.3, whiteSpace: 'normal', color: isError ? '#b91c1c' : '#15803d' }}>{message}</span>}
    </span>
  );
}