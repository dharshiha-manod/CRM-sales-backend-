import { VehicleMasterPage, VehicleModuleConfig } from './VehicleMasterPage';
import { orderPicker } from '../lib/vehicleOrderFill';

const STATUSES = ['Requested', 'Inspection', 'Valuation', 'Approved', 'Rejected', 'Converted'];

const config: VehicleModuleConfig = {
  resource: '/vehicle/exchanges',
  eyebrowModule: 'VEHICLE EXCHANGE',
  title: 'Trade-in / vehicle exchange',
  description: 'Customer trade-in vehicles, from inspection through valuation, approval and linking to the new-vehicle sales order.',
  icon: '↔',
  emptyIcon: '↔',
  codeField: 'exchange_id',
  nameField: 'client_name',
  statusOptions: STATUSES,
  searchableKeys: ['exchange_id', 'client_name', 'existing_registration_number', 'new_vehicle_vin'],
  fields: [
    { key: 'exchange_id', label: 'Exchange ID', type: 'text', required: true, listColumn: true, readOnly: true, autoGenerate: 'EXG' },
    { key: 'client_name', label: 'Client', type: 'text', required: true, listColumn: true },
    { key: 'client_id', label: 'Client (pick to link)', type: 'lookup', group: 'Link', lookupResource: '/clients', lookupLabelKey: 'client_name', autoFillMap: { client_name: 'client_name' } },
    { key: 'order_id', label: 'Core order', type: 'lookup', group: 'Link', ...orderPicker({ vin: 'new_vehicle_vin' }), autoFillMap: { sales_order_reference: 'order_number' } },
    { key: 'booking_number', label: 'Booking number (auto-linked)', type: 'text', readOnly: true, group: 'Link' },
    { key: 'existing_registration_number', label: 'Existing vehicle registration number', type: 'text', group: 'Existing vehicle' },
    { key: 'existing_make', label: 'Make', type: 'text', group: 'Existing vehicle' },
    { key: 'existing_model', label: 'Model', type: 'text', listColumn: true, group: 'Existing vehicle' },
    { key: 'existing_variant', label: 'Variant', type: 'text', group: 'Existing vehicle' },
    { key: 'manufacturing_year', label: 'Manufacturing year', type: 'number', group: 'Existing vehicle' },
    { key: 'odometer', label: 'Odometer', type: 'number', group: 'Existing vehicle' },
    { key: 'condition', label: 'Condition', type: 'select', options: ['Excellent', 'Good', 'Fair', 'Poor'], group: 'Existing vehicle' },
    { key: 'inspection_result', label: 'Inspection result', type: 'textarea', group: 'Valuation' },
    { key: 'estimated_value', label: 'Estimated value', type: 'number', group: 'Valuation' },
    { key: 'approved_value', label: 'Approved value', type: 'number', listColumn: true, group: 'Valuation' },
    { key: 'outstanding_loan', label: 'Outstanding loan', type: 'number', group: 'Valuation' },
    { key: 'net_exchange_value', label: 'Net exchange value', type: 'number', listColumn: true, group: 'Valuation' },
    { key: 'new_vehicle_vin', label: 'New vehicle (VIN)', type: 'lookup', group: 'New vehicle', lookupResource: '/vehicle/units', lookupLabelKey: 'vin', lookupSecondaryLabelKey: 'model_name', lookupValueKey: 'vin' },
    { key: 'sales_order_reference', label: 'Sales order reference (Core Orders)', type: 'text', group: 'New vehicle' },
    { key: 'status', label: 'Status', type: 'select', options: STATUSES, listColumn: true, group: 'New vehicle' },
  ],
  kpis: [
    { icon: '↔', iconClass: 'kpi-icon-ink', label: 'Total exchanges', value: (r) => String(r.length) },
    { icon: '◷', iconClass: 'kpi-icon-amber', label: 'In valuation', value: (r) => String(r.filter((x) => x.status === 'Inspection' || x.status === 'Valuation').length) },
    { icon: '✔', iconClass: 'kpi-icon-green', label: 'Approved / converted', value: (r) => String(r.filter((x) => x.status === 'Approved' || x.status === 'Converted').length) },
      { icon: '₹', iconClass: 'kpi-icon-school', label: 'Net exchange value', value: (r) => `₹${r.reduce((sum, x) => sum + (Number(x.net_exchange_value) || 0), 0).toLocaleString()}` },
  ],
  sampleRecords: [],
};

export function VehicleExchangePage() {
  return <VehicleMasterPage config={config} />;
}