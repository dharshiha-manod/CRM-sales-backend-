import { useEffect, useMemo, useState } from 'react';
import { api } from '../lib/api';
import { collectionsInInr, ordersInInr } from '../lib/inr';
import { useIndustryScope } from '../industry/useIndustryScope';
import { PharmaInsightsPanel } from './PharmaInsightsPanel';
import './DashboardPage.css';
type RecentVisit = { id: string; status: string; check_in_time: string; outcome?: string | null; clients?: { client_code?: string; client_name?: string } | null; sales_representatives?: { employee_code?: string; user_profiles?: { display_name?: string | null } | null } | null };
type Data = { totalClients: number; totalRepresentatives: number; activeRepresentatives: number; visitsToday: number; completedVisitsToday: number; activeVisits: number; ordersToday: number; salesToday: number; collectionsToday: number; recentVisits: RecentVisit[] };
type LiveVisit = { id: string; check_in_time: string; check_in_lat: number; check_in_lng: number; clients?: { client_code?: string; client_name?: string } | null; sales_representatives?: { employee_code?: string; user_profiles?: { display_name?: string | null } | null } | null; latest_ping?: { latitude: number; longitude: number } | null };
type Lead = { id: string; company_name?: string; contact_name?: string | null; source?: string; status: 'new' | 'contacted' | 'qualified' | 'unqualified' | 'converted' | 'lost'; created_at?: string; next_action?: string | null; next_action_due_at?: string | null; industry_types?: { id: string } | null };
type ClientRecord = { id: string; status: 'active' | 'inactive'; industry_type_id?: string | null };
type FollowUpRecord = { id: string; lead_id?: string | null; due_at: string; status: 'pending' | 'in_progress' | 'completed' | 'cancelled'; title?: string; clients?: { client_code?: string; client_name?: string } | null };
type OrderRecord = { id: string; order_number: string; total_amount: number; created_at: string; clients?: { client_code?: string } | null; sales_representatives?: { employee_code?: string; user_profiles?: { display_name?: string | null } | null } | null };
type CollectionRecord = { amount: number; clients?: { client_code?: string } | null; sale_orders?: { order_number?: string } | null };
type Call = { id: string; direction: string; phone_number: string; status: string; started_at?: string | null; clients?: { client_code?: string; client_name?: string | null } | null };
type TradingDeal = { id: string; deal_number: string; deal_name?: string; status: string; quantity?: number | string | null; purchase_rate?: number | string | null; purchase_discount_percent?: number | string | null; selling_rate?: number | string | null; industry_type_id?: string | null };
type DashboardFollowUp = { id: string; dueAt: string; title: string; clientName?: string };
type Extra = { leads: Lead[]; clients: ClientRecord[]; followUps: FollowUpRecord[]; orders: OrderRecord[]; collections: CollectionRecord[]; calls: Call[]; tradingDeals: TradingDeal[] };
const empty: Data = { totalClients: 0, totalRepresentatives: 0, activeRepresentatives: 0, visitsToday: 0, completedVisitsToday: 0, activeVisits: 0, ordersToday: 0, salesToday: 0, collectionsToday: 0, recentVisits: [] };
const emptyExtra: Extra = { leads: [], clients: [], followUps: [], orders: [], collections: [], calls: [], tradingDeals: [] };
const money = (value: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);
const timeLabel = (value?: string | null) => (value ? new Intl.DateTimeFormat(undefined, { timeStyle: 'short' }).format(new Date(value)) : '—');
const dateLabel = (value?: string | null) => (value ? new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short' }).format(new Date(value)) : '—');
const sourceLabels: Record<string, string> = { referral: 'Referral', cold_call: 'Cold call', walk_in: 'Walk-in', website: 'Website', exhibition: 'Exhibition', social_media: 'Social media', ivr: 'IVR / phone line', other: 'Other' };
const sourceColors: Record<string, string> = { referral: 'var(--accent-teal)', cold_call: 'var(--amber)', walk_in: 'var(--accent-violet)', website: 'var(--accent-blue)', exhibition: 'var(--ind-textile)', social_media: 'var(--accent-coral)', ivr: 'var(--green)', other: 'var(--text-faint)' };

type RangeKey = 'today' | 'week' | 'month' | 'quarter' | 'year' | 'custom';
const RANGES: { key: RangeKey; label: string }[] = [
  { key: 'today', label: 'Today' },
  { key: 'week', label: 'This Week' },
  { key: 'month', label: 'This Month' },
  { key: 'quarter', label: 'This Quarter' },
  { key: 'year', label: 'This Year' },
  { key: 'custom', label: 'Custom Date' },
];
function rangeBounds(key: RangeKey, customFrom: string, customTo: string): [Date, Date] {
  const now = new Date();
  const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const end = new Date(startOfDay(now).getTime()); end.setDate(end.getDate() + 1);
  if (key === 'today') return [startOfDay(now), end];
  if (key === 'week') { const s = startOfDay(now); s.setDate(s.getDate() - s.getDay()); return [s, end]; }
  if (key === 'month') return [new Date(now.getFullYear(), now.getMonth(), 1), end];
  if (key === 'quarter') { const q = Math.floor(now.getMonth() / 3); return [new Date(now.getFullYear(), q * 3, 1), end]; }
  if (key === 'year') return [new Date(now.getFullYear(), 0, 1), end];
  const parseLocal = (v: string) => { const [y, m, d] = v.split('-').map(Number); return new Date(y, m - 1, d); };
  const from = customFrom ? parseLocal(customFrom) : startOfDay(now);
  let to = end;
  if (customTo) { to = parseLocal(customTo); to.setDate(to.getDate() + 1); }
  if (to <= from) { to = new Date(from); to.setDate(to.getDate() + 1); }
  return [from, to];
}
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };

export function DashboardPage() {
  const { activeIndustry, activeIndustryTypeId } = useIndustryScope();
  const [data, setData] = useState<Data>(empty); const [live, setLive] = useState<LiveVisit[]>([]); const [extra, setExtra] = useState<Extra>(emptyExtra); const [error, setError] = useState('');  
  const [range, setRange] = useState<RangeKey>('today');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const [calendarMonth, setCalendarMonth] = useState(() => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), 1); });
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);

  const [rangeStart, rangeEnd] = useMemo(() => rangeBounds(range, customFrom, customTo), [range, customFrom, customTo]);
  const rangeFromIso = rangeStart.toISOString();
  const rangeToIso = rangeEnd.toISOString();
  const rangeLabel = RANGES.find((r) => r.key === range)?.label ?? '';
  const suffix = range === 'today' ? 'today' : range === 'custom' ? 'in range' : rangeLabel.toLowerCase();

  useEffect(() => {
    // Do not load the organisation-wide dashboard and then try to hide values
    // in the browser. Every request below is explicitly scoped to the active
    // industry, so a Trading dashboard cannot show another industry's leads,
    // orders, collections, or follow-ups while the industry lookup is loading.
    if (!activeIndustryTypeId) {
      setData(empty);
      setLive([]);
      setExtra(emptyExtra);
      return;
    }

    const industryQuery = `?industryTypeId=${encodeURIComponent(activeIndustryTypeId)}`;
    const dashboardQuery = `${industryQuery}&from=${encodeURIComponent(rangeFromIso)}&to=${encodeURIComponent(rangeToIso)}`;
    const load = () => void Promise.all([
      api<{ data: Data }>(`/dashboard${dashboardQuery}`),
      api<{ data: LiveVisit[] }>(`/field-visits/live${industryQuery}`),
      api<{ data: Lead[] }>(`/leads${industryQuery}`).catch(() => ({ data: [] })),
      api<{ data: ClientRecord[] }>(`/clients${industryQuery}`).catch(() => ({ data: [] })),
      api<{ data: FollowUpRecord[] }>(`/follow-ups${industryQuery}`).catch(() => ({ data: [] })),
      api<{ data: OrderRecord[] }>(`/orders${industryQuery}`).then(ordersInInr).catch(() => ({ data: [] })),
      api<{ data: CollectionRecord[] }>(`/collections${industryQuery}`).then(collectionsInInr).catch(() => ({ data: [] })),
      api<{ data: Call[] }>(`/telephony/calls${industryQuery}`).catch(() => ({ data: [] })),
      api<{ data: TradingDeal[] }>(`/trading/deals${industryQuery}`).catch(() => ({ data: [] })),
    ]).then(([dashboard, activity, leads, clients, followUps, orders, collections, calls, tradingDeals]) => {
      setData({ ...empty, ...dashboard.data });
      setLive(activity.data);
      setExtra({ leads: leads.data ?? [], clients: clients.data ?? [], followUps: followUps.data ?? [], orders: orders.data ?? [], collections: collections.data ?? [], calls: calls.data ?? [], tradingDeals: tradingDeals.data ?? [] });
      setError('');
    }).catch((reason) => setError((reason as Error).message));
    load();
    const timer = window.setInterval(load, 20000);
    return () => window.clearInterval(timer);
  }, [activeIndustryTypeId, rangeFromIso, rangeToIso]);

  // Trading pipeline snapshot for the dashboard's Trading section — reuses
  // the same margin math as TradingDealPage.tsx so the numbers always agree.
  // The API request above is industry-scoped. Keeping this list untouched
  // avoids a second, client-side approximation of the server's real scope.
  const tradingDealsInScope = extra.tradingDeals;
  const tradingStats = useMemo(() => {
    const openStatuses = ['Completed', 'Cancelled', 'Lost'];
    const sellingValue = (d: TradingDeal) => (Number(d.selling_rate) || 0) * (Number(d.quantity) || 0);
    const purchaseValue = (d: TradingDeal) => (Number(d.purchase_rate) || 0) * (Number(d.quantity) || 0) * (1 - (Number(d.purchase_discount_percent) || 0) / 100);
    const open = tradingDealsInScope.filter((d) => !openStatuses.includes(d.status));
    const dealValue = tradingDealsInScope.reduce((sum, d) => sum + sellingValue(d), 0);
    const expectedMargin = tradingDealsInScope.reduce((sum, d) => sum + (sellingValue(d) - purchaseValue(d)), 0);
    return { total: tradingDealsInScope.length, open: open.length, dealValue, expectedMargin };
  }, [tradingDealsInScope]);
  const inRange = (value?: string | null) => { if (!value) return false; const d = new Date(value); return d >= rangeStart && d < rangeEnd; };

  const rangeLeads = useMemo(() => extra.leads.filter((l) => inRange(l.created_at)), [extra.leads, rangeStart, rangeEnd]);

  const rangeOrders = useMemo(() => extra.orders.filter((o) => inRange(o.created_at)), [extra.orders, rangeStart, rangeEnd]);
  const rangeCalls = useMemo(() => extra.calls.filter((c) => inRange(c.started_at)), [extra.calls, rangeStart, rangeEnd]);

  const leadStats = (() => {
    const total = rangeLeads.length;
    const converted = rangeLeads.filter((l) => l.status === 'converted').length;
    const lost = rangeLeads.filter((l) => l.status === 'lost').length;
    const open = total - converted - lost;
    const conversionRate = total ? Math.round((converted / total) * 100) : 0;
    return { total, open, converted, conversionRate };
  })();

  const activeClients = extra.clients.filter((c) => c.status === 'active').length;

  // Lead "Next follow-up" dates live on leads, while Follow-ups page items
  // live in follow_ups. The dashboard needs both sources to show all real
  // pending work, including overdue lead follow-ups.
  const dashboardFollowUps = useMemo<DashboardFollowUp[]>(() => [
    ...extra.followUps
      .filter((followUp) => followUp.status !== 'completed' && followUp.status !== 'cancelled')
      .map((followUp) => ({
        id: `follow-up-${followUp.id}`,
        dueAt: followUp.due_at,
        title: followUp.title ?? 'Follow-up',
        clientName: followUp.clients?.client_name,
      })),
      ...extra.leads
      .filter((lead) => Boolean(lead.next_action_due_at) && lead.status !== 'converted' && lead.status !== 'lost'
        && !extra.followUps.some((f) => f.lead_id === lead.id && f.status !== 'completed' && f.status !== 'cancelled'))
      .map((lead) => ({
        id: `lead-${lead.id}`,
        dueAt: lead.next_action_due_at!,
        title: lead.next_action?.trim() || `Follow up: ${lead.company_name ?? lead.contact_name ?? 'lead'}`,
        clientName: lead.company_name ?? lead.contact_name ?? undefined,
      })),
  ], [extra.followUps, extra.leads]);

  const followUpStats = (() => {
    const now = new Date();
    const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const endToday = new Date(startToday);
    endToday.setDate(endToday.getDate() + 1);
    let overdue = 0, dueToday = 0, upcoming = 0;
    dashboardFollowUps.forEach((f) => {
      const due = new Date(f.dueAt);
      if (due < startToday) overdue += 1;
      else if (due < endToday) dueToday += 1;
      else upcoming += 1;
    });
    return { overdue, dueToday, upcoming, pending: overdue + dueToday + upcoming };
  })();

  const pendingPayments = (() => {
    const collectedByOrder: Record<string, number> = {};
    extra.collections.forEach((c) => {
      const key = c.sale_orders?.order_number;
      if (!key) return;
      collectedByOrder[key] = (collectedByOrder[key] ?? 0) + Number(c.amount || 0);
    });
    return extra.orders.reduce((sum, o) => {
      const paid = collectedByOrder[o.order_number] ?? 0;
      return sum + Math.max(Number(o.total_amount) - paid, 0);
    }, 0);
  })();

  const kpis: { label: string; value: string | number; note: string; icon: string }[] = [
    { label: `Visits ${suffix}`, value: data.visitsToday, note: `${data.completedVisitsToday} completed`, icon: '📍' },
    { label: 'Active field visits', value: live.length, note: live.length ? 'GPS reporting active' : 'No one checked in', icon: '🛰️' },
    { label: `Orders ${suffix}`, value: data.ordersToday, note: money(data.salesToday), icon: '🧾' },
    { label: `Collections ${suffix}`, value: money(data.collectionsToday), note: 'Recorded receipts', icon: '💰' },
    { label: `Leads ${suffix}`, value: leadStats.total, note: `${leadStats.open} open · ${leadStats.conversionRate}% converted`, icon: '🎯' },
    { label: 'Active clients', value: activeClients, note: `of ${extra.clients.length} total clients`, icon: '🏢' },
    { label: 'Follow-ups due', value: followUpStats.pending, note: `${followUpStats.overdue} overdue · ${followUpStats.dueToday} today`, icon: '⏰' },
    { label: 'Pending payments', value: money(pendingPayments), note: 'Outstanding across all orders', icon: '⚠️' },
  ];

  const repPerformance = (() => {
    const byRep: Record<string, { name: string; orders: number; revenue: number }> = {};
    rangeOrders.forEach((o) => {
      const key = o.sales_representatives?.employee_code ?? 'unassigned';
      const name = o.sales_representatives?.user_profiles?.display_name ?? o.sales_representatives?.employee_code ?? 'Unassigned';
      if (!byRep[key]) byRep[key] = { name, orders: 0, revenue: 0 };
      byRep[key].orders += 1;
      byRep[key].revenue += Number(o.total_amount || 0);
    });
    return Object.values(byRep).sort((a, b) => b.revenue - a.revenue).slice(0, 5);
  })();

  const callsToday = rangeCalls;
  const callStats = { total: callsToday.length, inbound: callsToday.filter((c) => c.direction === 'inbound').length, outbound: callsToday.filter((c) => c.direction === 'outbound').length, missed: callsToday.filter((c) => c.status === 'missed' || c.status === 'no_answer').length };

  const leadBreakdown = (() => {
    const statuses: { key: Lead['status']; label: string; color: string }[] = [
      { key: 'new', label: 'New', color: 'var(--amber)' },
      { key: 'contacted', label: 'Contacted', color: 'var(--ind-school)' },
      { key: 'qualified', label: 'Qualified', color: 'var(--ind-textile)' },
      { key: 'converted', label: 'Converted', color: 'var(--green)' },
      { key: 'unqualified', label: 'Unqualified', color: 'var(--text-faint)' },
      { key: 'lost', label: 'Lost', color: 'var(--red)' },
    ];
    const counts = statuses.map((s) => ({ ...s, value: rangeLeads.filter((l) => l.status === s.key).length }));
    return { counts, max: Math.max(1, ...counts.map((c) => c.value)) };
  })();

  const leadSourceBreakdown = useMemo(() => {
    const counts: Record<string, number> = {};
    rangeLeads.forEach((l) => { const key = l.source ?? 'other'; counts[key] = (counts[key] ?? 0) + 1; });
    const total = rangeLeads.length;
    return { entries: Object.entries(counts).sort((a, b) => b[1] - a[1]), total };
  }, [rangeLeads]);

  const revenueTrend = (() => {
    const buckets: { label: string; start: Date; end: Date }[] = [];
    const spanDays = Math.round((rangeEnd.getTime() - rangeStart.getTime()) / 86400000);
    if (spanDays <= 31) {
      // Daily bars. "Today" alone would be one bar, so show the last 7 days instead.
      const first = range === 'today' ? addDays(rangeStart, -6) : rangeStart;
      for (let d = new Date(first); d < rangeEnd; d = addDays(d, 1)) {
        buckets.push({ label: d.toLocaleDateString(undefined, spanDays <= 7 || range === 'today' ? { weekday: 'short' } : { day: '2-digit', month: 'short' }), start: d, end: addDays(d, 1) });
      }
    } else {
      // Monthly bars for quarter / year / long custom ranges.
      for (let m = new Date(rangeStart.getFullYear(), rangeStart.getMonth(), 1); m < rangeEnd; m = new Date(m.getFullYear(), m.getMonth() + 1, 1)) {
        const next = new Date(m.getFullYear(), m.getMonth() + 1, 1);
        buckets.push({ label: m.toLocaleDateString(undefined, { month: 'short' }), start: m < rangeStart ? rangeStart : m, end: next > rangeEnd ? rangeEnd : next });
      }
    }
    const days = buckets.map((b) => ({
      label: b.label,
      value: extra.orders.filter((o) => { const c = new Date(o.created_at); return c >= b.start && c < b.end; }).reduce((sum, o) => sum + Number(o.total_amount || 0), 0),
    }));
    return { days, max: Math.max(1, ...days.map((d) => d.value)) };
  })();

  const followUpDonut = (() => {
    const total = followUpStats.pending;
    if (!total) return null;
    const overduePct = (followUpStats.overdue / total) * 100;
    const todayPct = (followUpStats.dueToday / total) * 100;
    return { overduePct, todayPct, total };
  })();

  const calendarDays = useMemo(() => {
    const year = calendarMonth.getFullYear(); const month = calendarMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const startOffset = firstDay.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: (Date | null)[] = [];
    for (let i = 0; i < startOffset; i += 1) cells.push(null);
    for (let d = 1; d <= daysInMonth; d += 1) cells.push(new Date(year, month, d));
    while (cells.length % 7 !== 0) cells.push(null);
    return cells;
  }, [calendarMonth]);

  const followUpsByDay = useMemo(() => {
    const map: Record<string, number> = {};
    dashboardFollowUps.forEach((f) => { const d = new Date(f.dueAt); const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`; map[key] = (map[key] ?? 0) + 1; });
    return map;
  }, [dashboardFollowUps]);

  const scheduleDay = selectedDay ?? new Date();
  const scheduleFollowUps = useMemo(() => dashboardFollowUps.filter((f) => { const d = new Date(f.dueAt); return d.getFullYear() === scheduleDay.getFullYear() && d.getMonth() === scheduleDay.getMonth() && d.getDate() === scheduleDay.getDate(); }), [dashboardFollowUps, scheduleDay]);

  const recentLeads = useMemo(() => [...rangeLeads].sort((a, b) => new Date(b.created_at ?? 0).getTime() - new Date(a.created_at ?? 0).getTime()).slice(0, 6), [rangeLeads]);

  const today = new Date();
  const isSameDay = (a: Date, b: Date) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

  return <>
    <section className="ops-hero">
      <div><p className="eyebrow">Sales CRM</p><h2>Dashboard</h2><p>Overview of your sales pipeline, field activity, and collections</p></div>
      <div className="ops-date"><span>Today</span><strong>{new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date())}</strong><small>{data.activeRepresentatives} active representatives</small></div>
    </section>

    <div className="range-bar">
      {RANGES.map((r) => <button key={r.key} className={`range-pill ${range === r.key ? 'active' : ''}`} onClick={() => setRange(r.key)}>{r.label}</button>)}
      {range === 'custom' && (
        <span className="range-custom">
          <input type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} />
          <span>to</span>
          <input type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)} />
        </span>
      )}
      <span className="range-showing">Showing: {RANGES.find((r) => r.key === range)?.label}{range === 'custom' && customFrom && customTo ? ` (${dateLabel(customFrom)} – ${dateLabel(customTo)})` : ''}</span>
    </div>

    {error ? <section className="access-card"><h2>Dashboard data is unavailable</h2><p>{error}</p></section> : <>
       <div className="ops-metrics">
        {kpis.map((k, index) => (
          <section className={`ops-metric tone-${index}`} key={k.label}>
            <div className="ops-metric-icon">{k.icon}</div>
            <p>{k.label}</p>
            <strong>{k.value}</strong>
            <small>{k.note}</small>
          </section>
        ))}
       </div>

      {activeIndustry === 'pharma' && activeIndustryTypeId && <PharmaInsightsPanel industryTypeId={activeIndustryTypeId} />}
      {activeIndustry === 'trading' && (
        <section className="ops-panel">
          <header><div><p className="eyebrow">TRADING</p><h2>Deal pipeline</h2></div></header>
          <div className="ops-metrics">
            <section className="ops-metric tone-0">
              <div className="ops-metric-icon">◆</div>
              <p>Total deals</p>
              <strong>{tradingStats.total}</strong>
            </section>
            <section className="ops-metric tone-1">
              <div className="ops-metric-icon">◷</div>
              <p>Open deals</p>
              <strong>{tradingStats.open}</strong>
            </section>
            <section className="ops-metric tone-2">
              <div className="ops-metric-icon">₹</div>
              <p>Deal value</p>
              <strong>{money(tradingStats.dealValue)}</strong>
            </section>
            <section className="ops-metric tone-3">
              <div className="ops-metric-icon">↗</div>
              <p>Expected margin</p>
              <strong>{money(tradingStats.expectedMargin)}</strong>
            </section>
          </div>
        </section>
      )}

      <div className="chart-grid">
        <section className="ops-panel chart-panel">
          <header><div><p className="eyebrow">{rangeLabel}</p><h2>Leads by stage</h2></div></header>
          <div className="bar-chart">
            {leadBreakdown.counts.map((c) => (
              <div className="bar-row" key={c.label}>
                <span className="bar-label">{c.label}</span>
                <div className="bar-track"><div className="bar-fill" style={{ width: `${(c.value / leadBreakdown.max) * 100}%`, background: c.color }} /></div>
                <span className="bar-value">{c.value}</span>
              </div>
            ))}
          </div>
        </section>
        <section className="ops-panel chart-panel">
          <header><div><p className="eyebrow">{range === 'today' ? 'Last 7 days' : rangeLabel}</p><h2>Revenue trend</h2></div></header>
          <div className="trend-chart">
            {revenueTrend.days.map((d, index) => (
              <div className="trend-col" key={index}>
                <span className="trend-value">{d.value && revenueTrend.days.length <= 8 ? money(d.value) : ''}</span>
                <div className="trend-bar" style={{ height: `${Math.max(4, (d.value / revenueTrend.max) * 100)}%` }} title={`${d.label}: ${money(d.value)}`} />
                <span className="trend-label">{d.label}</span>
              </div>
            ))}
          </div>
        </section>
        <section className="ops-panel chart-panel">
          <header><div><p className="eyebrow">{rangeLabel}</p><h2>Lead source</h2></div></header>
          {leadSourceBreakdown.total ? (
            <ul className="source-list">
              {leadSourceBreakdown.entries.map(([key, count]) => (
                <li key={key}>
                  <i style={{ background: sourceColors[key] ?? 'var(--text-faint)' }} />
                  <span>{sourceLabels[key] ?? key}</span>
                  <div className="source-track"><div className="source-fill" style={{ width: `${(count / leadSourceBreakdown.total) * 100}%`, background: sourceColors[key] ?? 'var(--text-faint)' }} /></div>
                  <b>{count}</b>
                </li>
              ))}
            </ul>
          ) : (
            <div className="ops-empty"><strong>No source data</strong><p>No leads created in this date range yet.</p></div>
          )}
        </section>
      </div>

      <div className="ops-grid">
        <section className="ops-panel chart-panel donut-panel">
          <header><div><p className="eyebrow">Follow-ups</p><h2>Due breakdown</h2></div></header>
          {followUpDonut ? (
            <div className="donut-wrap">
              <div className="donut" style={{ background: `conic-gradient(var(--red) 0 ${followUpDonut.overduePct}%, var(--amber) ${followUpDonut.overduePct}% ${followUpDonut.overduePct + followUpDonut.todayPct}%, var(--green) ${followUpDonut.overduePct + followUpDonut.todayPct}% 100%)` }}>
                <div className="donut-hole"><strong>{followUpDonut.total}</strong><span>pending</span></div>
              </div>
              <ul className="donut-legend">
                <li><i style={{ background: 'var(--red)' }} />Overdue · {followUpStats.overdue}</li>
                <li><i style={{ background: 'var(--amber)' }} />Due today · {followUpStats.dueToday}</li>
                <li><i style={{ background: 'var(--green)' }} />Upcoming · {followUpStats.upcoming}</li>
              </ul>
            </div>
          ) : (
            <div className="ops-empty"><strong>All caught up</strong><p>No pending follow-ups right now.</p></div>
          )}
        </section>
        <section className="ops-panel">
          <header>
            <div><p className="eyebrow">Field locations</p><h2>Reps currently checked in</h2></div>
            {live.length > 0 && <span>{live.length} live</span>}
          </header>
          {live.length ? (
            <div className="live-list">
              {live.map((visit) => {
                const lat = visit.latest_ping?.latitude ?? visit.check_in_lat;
                const lng = visit.latest_ping?.longitude ?? visit.check_in_lng;
                return (
                  <article key={visit.id}>
                    <i />
                    <div>
                      <strong>{visit.sales_representatives?.user_profiles?.display_name ?? visit.sales_representatives?.employee_code ?? 'Unassigned rep'}</strong>
                      <p>{visit.clients?.client_name ?? 'Unknown client'} · {lat != null && lng != null ? `${lat.toFixed(4)}, ${lng.toFixed(4)}` : 'No GPS ping yet'}</p>
                    </div>
                    <time>Since {timeLabel(visit.check_in_time)}</time>
                    {lat != null && lng != null && <a href={`https://www.google.com/maps?q=${lat},${lng}`} target="_blank" rel="noreferrer">Map</a>}
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="ops-empty"><strong>No one is checked in</strong><p>Live GPS-verified visit locations appear here as soon as a representative checks in from the mobile app.</p></div>
          )}
        </section>
      </div>

      <div className="ops-grid">
        <section className="ops-panel">
          <header><div><p className="eyebrow">Pipeline</p><h2>Recent leads</h2></div><span>{rangeLeads.length} in range</span></header>
          {recentLeads.length ? (
            <div className="recent-leads-list">
              {recentLeads.map((lead) => (
                <article key={lead.id}>
                  <div>
                    <strong>{lead.company_name ?? lead.contact_name ?? 'Untitled lead'}</strong>
                    <p>{sourceLabels[lead.source ?? 'other'] ?? lead.source} · {lead.status.replace('_', ' ')}</p>
                  </div>
                  <time>{dateLabel(lead.created_at)}</time>
                </article>
              ))}
            </div>
          ) : (
            <div className="ops-empty"><strong>No leads for this date range</strong><p>Leads created in the selected period will appear here.</p></div>
          )}
        </section>
        <section className="ops-panel calendar-panel">
          <header>
            <div><p className="eyebrow">Follow-ups</p><h2>Today's schedule</h2></div>
            <span>Open</span>
          </header>
          <div className="calendar-head">
            <button onClick={() => setCalendarMonth((m) => new Date(m.getFullYear(), m.getMonth() - 1, 1))}>‹</button>
            <strong>{calendarMonth.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</strong>
            <button onClick={() => setCalendarMonth((m) => new Date(m.getFullYear(), m.getMonth() + 1, 1))}>›</button>
          </div>
          <div className="calendar-grid">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => <span className="calendar-dow" key={i}>{d}</span>)}
            {calendarDays.map((d, i) => {
              if (!d) return <span key={i} />;
              const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
              const has = followUpsByDay[key] > 0;
              const isTodayCell = isSameDay(d, today);
              const isSelected = selectedDay ? isSameDay(d, selectedDay) : isTodayCell;
              return (
                <button key={i} className={`calendar-cell ${isSelected ? 'selected' : ''} ${isTodayCell && !isSelected ? 'today' : ''}`} onClick={() => setSelectedDay(d)}>
                  {d.getDate()}
                  {has && <i className="calendar-dot" />}
                </button>
              );
            })}
          </div>
          <div className="calendar-schedule">
            {scheduleFollowUps.length ? scheduleFollowUps.map((f) => (
              <div className="calendar-item" key={f.id}><strong>{f.title}</strong><span>{f.clientName ?? ''} · {timeLabel(f.dueAt)}</span></div>
            )) : <p className="ops-empty-inline">No follow-ups scheduled for this date range</p>}
          </div>
        </section>
      </div>

      <div className="ops-grid">
        <section className="ops-panel">
          <header><div><p className="eyebrow">{rangeLabel}</p><h2>Latest field visits</h2></div></header>
          {data.recentVisits.length ? (
            <div className="timeline">
              {data.recentVisits.map((visit) => (
                <article key={visit.id}>
                  <i className={visit.status} />
                  <div>
                    <strong>{visit.clients?.client_name ?? 'Unknown client'}</strong>
                    <p>{visit.sales_representatives?.user_profiles?.display_name ?? visit.sales_representatives?.employee_code ?? 'Unassigned'} · {visit.outcome ?? visit.status.replace('_', ' ')}</p>
                  </div>
                  <time>{timeLabel(visit.check_in_time)}</time>
                </article>
              ))}
            </div>
          ) : (
            <div className="ops-empty"><strong>No visits in this date range</strong><p>Field visit check-ins and check-outs will show up here as they happen.</p></div>
          )}
        </section>
        <section className="sales-today ops-panel">
          <p className="eyebrow">{rangeLabel}</p>
          <h2>{money(data.salesToday)}</h2>
          <div><span>Orders {suffix}</span><b>{data.ordersToday}</b></div>
          <div><span>Collections {suffix}</span><b>{money(data.collectionsToday)}</b></div>
          <div><span>Pending across all orders</span><b>{money(pendingPayments)}</b></div>
        </section>
      </div>
      <div className="ops-grid">
        <section className="ops-panel">
          <header><div><p className="eyebrow">Team</p><h2>Top representatives by order value</h2></div></header>
          {repPerformance.length ? (
            <div className="rep-performance-list">
              {repPerformance.map((rep, index) => (
                <article key={rep.name}>
                  <span className="rep-rank">#{index + 1}</span>
                  <div><strong>{rep.name}</strong><p>{rep.orders} order{rep.orders === 1 ? '' : 's'}</p></div>
                  <b>{money(rep.revenue)}</b>
                </article>
              ))}
            </div>
          ) : (
            <div className="ops-empty"><strong>No orders in this date range</strong><p>Rep performance ranks by total order value for the selected period.</p></div>
          )}
        </section>
        <section className="ops-readiness">
          <p className="eyebrow">Health</p>
          <h2>Leads &amp; follow-ups</h2>
          <div><span className={leadStats.total ? 'done' : ''}>{leadStats.total ? '✓' : '○'}</span><p><strong>Lead conversion</strong><small>{leadStats.converted} of {leadStats.total} leads converted {suffix} ({leadStats.conversionRate}%)</small></p></div>
          <div><span className={followUpStats.overdue === 0 && followUpStats.pending > 0 ? 'done' : ''}>{followUpStats.overdue === 0 ? '✓' : '○'}</span><p><strong>Follow-up discipline</strong><small>{followUpStats.overdue ? `${followUpStats.overdue} overdue follow-up(s) need attention` : `${followUpStats.pending} pending, none overdue`}</small></p></div>
          <div><span>○</span><p><strong>Sales target vs achievement</strong><small>Not available yet — connect a targets endpoint to track this here</small></p></div>
        </section>
      </div>
      <div className="ops-grid">
        <section className="ops-panel">
          <header><div><p className="eyebrow">Support</p><h2>Calls {suffix}</h2></div></header>
          <div className="ops-readiness" style={{ background: 'transparent', padding: 0 }}>
            <div><span className={callStats.total ? 'done' : ''}>{callStats.total ? '✓' : '○'}</span><p><strong>{callStats.total} call{callStats.total === 1 ? '' : 's'} {suffix}</strong><small>{callStats.inbound} inbound · {callStats.outbound} outbound</small></p></div>
            <div><span className={callStats.missed === 0 && callStats.total > 0 ? 'done' : ''}>{callStats.missed === 0 ? '✓' : '○'}</span><p><strong>Missed / unanswered</strong><small>{callStats.missed ? `${callStats.missed} call(s) need follow-up` : `None missed ${suffix}`}</small></p></div>
            <div><span>○</span><p><strong>Recent callers</strong><small>{callsToday.slice(0, 3).map((c) => c.clients?.client_name ?? c.phone_number).join(', ') || `No calls logged ${suffix}`}</small></p></div>
          </div>
        </section>
        <section className="ops-readiness">
          <p className="eyebrow">Team</p>
          <h2>Rep coverage</h2>
          <div><span className="done">✓</span><p><strong>{data.totalRepresentatives} representatives total</strong><small>{data.activeRepresentatives} active today</small></p></div>
          <div><span className={activeClients ? 'done' : ''}>{activeClients ? '✓' : '○'}</span><p><strong>{activeClients} active clients</strong><small>of {extra.clients.length} total on record</small></p></div>
        </section>
      </div>
    </>}
  </>;
}