// FILE: admin/src/components/TradingShipmentPage.tsx
import { TradingMasterPage, TradingModuleConfig } from './TradingMasterPage';
import { GenerateDocumentButton } from './GenerateDocumentButton';
import { ShipmentDocumentsChecklist } from './ShipmentDocumentsChecklist';
import { buildDraftFromShipment } from '../lib/tradeDocumentHandoff';
import { LinkedRecords } from './LinkedRecords';
import { useEffect, useState } from 'react';
import { SendShipmentDocumentsButton, SendShipmentDocumentsMenuItem, SEND_SHIPMENT_DOCS_EVENT } from './SendShipmentDocumentsButton';
import { TRADING_HASH } from '../lib/recordFocus';

const STATUSES = ['Planned', 'Ready to Ship', 'Dispatched', 'In Transit', 'At Destination', 'Delivered', 'Delayed', 'Cancelled'];
const SHIPMENT_DOC_TYPES = ['Packing List', 'Commercial Invoice', 'Delivery Note', 'Bill of Lading', 'Airway Bill', 'Certificate of Origin', 'Insurance Certificate', 'Inspection Certificate', 'Shipping Instructions', 'Transport Document', 'Other'];

// Moving a shipment is a Logistics decision: the plan must be complete first. So typing a date here no longer
// flips the status to "In Transit" by itself. It only marks a shipment that is already moving as Delayed.
const MOVING_STATUSES = new Set(['Dispatched', 'In Transit', 'At Destination']);

function deriveShipmentStatus(form: Record<string, string>): Record<string, string> | void {
  if (!MOVING_STATUSES.has(form.status ?? '')) return;
  if (form.expected_delivery_date && new Date() > new Date(form.expected_delivery_date)) return { status: 'Delayed' };
}

function deriveActualDeliveryDate(form: Record<string, string>): Record<string, string> | void {
  if (form.status !== 'Delivered' || form.actual_delivery_date) return;
  return { actual_delivery_date: new Date().toISOString().slice(0, 10) };
}
const config: TradingModuleConfig = {
  resource: '/trading/shipments',
  eyebrowModule: 'SHIPMENT MANAGEMENT',
  title: 'Shipment management',
  description: 'Track goods movement from supplier to customer against a confirmed deal — dispatch, transit, and delivery.',
  icon: '🚚',
  emptyIcon: '🚚',
  codeField: 'shipment_number',
  nameField: 'product_name',
  statusOptions: STATUSES,
  inlineStatus: true,
  fitToScreen: true,
  inlineStatusExtra: (record, next) => (next === 'Delivered' && !record.actual_delivery_date ? { actual_delivery_date: new Date().toISOString().slice(0, 10) } : undefined),
  searchableKeys: ['shipment_number', 'deal_number', 'customer_name', 'supplier_name', 'product_name', 'tracking_number'],
  fields: [
    {
      key: 'shipment_number', label: 'Shipment', type: 'text', required: true, listColumn: true, readOnly: true, autoGenerate: 'SHP',
      render: (_v, r) => (
        <span style={{ display: 'inline-flex', flexDirection: 'column', lineHeight: 1.25 }}>
          <strong style={{ fontWeight: 600 }}>{String(r.shipment_number ?? '—')}</strong>
          <span style={{ color: '#64748b', fontSize: '.74rem' }}>{r.deal_number ? `Deal: ${String(r.deal_number)}` : 'No deal linked'}</span>
        </span>
      ),
    },
  { key: 'deal_number', label: 'Deal', type: 'lookup', lookupResource: '/trading/deals', lookupLabelKey: 'deal_name', autoFillMap: { customer_name: 'customer_name', supplier_name: 'supplier_name', product_name: 'product_name', quantity: 'quantity', customer_quantity: 'quantity', unit: 'unit', currency: 'currency' } },
    { key: 'order_number', label: 'Sales order', type: 'text', readOnly: true, listColumn: true, group: 'Goods' },
    { key: 'customer_name', label: 'Customer', type: 'lookup', lookupResource: '/clients', lookupValueKey: 'client_name', lookupLabelKey: 'client_code', listColumn: true, group: 'Goods' },
    { key: 'supplier_name', label: 'Supplier', type: 'lookup', lookupResource: '/trading/suppliers', lookupLabelKey: 'supplier_name', group: 'Goods' },
    { key: 'product_name', label: 'Product', type: 'text', group: 'Goods' },
    { key: 'quantity', label: 'Quantity', type: 'number', group: 'Goods' },
    { key: 'unit', label: 'Unit', type: 'text', group: 'Goods' },
    { key: 'batch_serial', label: 'Batch / serial information', type: 'text', group: 'Goods' },
    { key: 'shipment_date', label: 'Shipment date', type: 'date', group: 'Schedule', onValueChange: (_v, f) => deriveShipmentStatus(f) },
    {
      key: 'expected_delivery_date', label: 'Delivery (expected / actual)', type: 'date', listColumn: true, group: 'Schedule', onValueChange: (_v, f) => deriveShipmentStatus(f),
      render: (_v, r) => (
        <span style={{ display: 'inline-flex', flexDirection: 'column', lineHeight: 1.25 }}>
          <span>{r.expected_delivery_date ? `Exp: ${String(r.expected_delivery_date)}` : 'Exp: —'}</span>
          <span style={{ color: r.actual_delivery_date ? '#166534' : '#64748b', fontSize: '.78rem' }}>{r.actual_delivery_date ? `Act: ${String(r.actual_delivery_date)}` : 'Act: —'}</span>
        </span>
      ),
    },
      { key: 'actual_delivery_date', label: 'Actual delivery date', type: 'date', group: 'Schedule', helpText: 'The date the goods were really delivered - it cannot be in the future.' },
    { key: 'origin', label: 'Origin', type: 'text', readOnly: true, group: 'Route (from Logistics)', helpText: 'Filled from the Logistics plan. Edit it on the Logistics page.' },
    { key: 'destination', label: 'Destination', type: 'text', readOnly: true, group: 'Route (from Logistics)' },
    { key: 'transporter', label: 'Transporter / logistics provider', type: 'text', readOnly: true, group: 'Route (from Logistics)' },
    { key: 'tracking_number', label: 'Tracking number', type: 'text', readOnly: true, group: 'Route (from Logistics)' },
    { key: 'vehicle_container_number', label: 'Vehicle / container number', type: 'text', readOnly: true, group: 'Route (from Logistics)' },
    { key: 'shipping_mode', label: 'Shipping mode', type: 'text', readOnly: true, listColumn: true, group: 'Route (from Logistics)' },
    { key: 'freight_cost', label: 'Freight cost (as entered in Logistics)', type: 'number', readOnly: true, group: 'Route (from Logistics)', helpText: 'In the currency used on the Logistics record. Converted figures are on the Logistics page.' },
 { key: 'status', label: 'Shipment status', type: 'select', options: STATUSES, listColumn: true, group: 'Status', onValueChange: (_v, f) => deriveActualDeliveryDate(f), helpText: 'Dispatch is blocked until the Logistics plan has a carrier, origin, destination and pickup or departure date.' },
    { key: 'notes', label: 'Notes', type: 'textarea', group: 'Status' },
  ],
  kpis: [
    { icon: '🚚', iconClass: 'kpi-icon-ink', label: 'Total shipments', value: (r) => String(r.length) },
    { icon: '↗', iconClass: 'kpi-icon-amber', label: 'In transit', value: (r) => String(r.filter((x) => x.status === 'In Transit' || x.status === 'Dispatched').length) },
    { icon: '✔', iconClass: 'kpi-icon-green', label: 'Delivered', value: (r) => String(r.filter((x) => x.status === 'Delivered').length) },
    { icon: '⚠', iconClass: 'kpi-icon-red', label: 'Delayed', value: (r) => String(r.filter((x) => x.status === 'Delayed').length) },
    {
      icon: '⏱',
      iconClass: 'kpi-icon-school',
      label: 'On-time delivery rate',
      value: (r) => {
        const delivered = r.filter((x) => x.status === 'Delivered' && x.actual_delivery_date && x.expected_delivery_date);
        if (!delivered.length) return '—';
        const onTime = delivered.filter((x) => new Date(x.actual_delivery_date as string) <= new Date(x.expected_delivery_date as string));
        return `${Math.round((onTime.length / delivered.length) * 100)}%`;
      },
    },
  ],
  rowActions: (r) => (
    <>
      <GenerateDocumentButton docTypes={SHIPMENT_DOC_TYPES} buildDraft={(documentType) => buildDraftFromShipment(r, documentType)} />
      <SendShipmentDocumentsMenuItem shipment={r} />
    </>
  ),
  // Documents remain a manual action. They become available on the detail
  // view once delivery is confirmed; no document is generated automatically.
  detailActions: (r) => (
    <>
      {r.status === 'Delivered' && (
        <GenerateDocumentButton label="Generate delivery document" docTypes={SHIPMENT_DOC_TYPES} buildDraft={(documentType) => buildDraftFromShipment(r, documentType)} />
      )}
      <SendShipmentDocumentsButton shipment={r} />
    </>
  ),
  // The documents checklist stays as-is; the chain panel below it is new —
  // a shipment is the hub of the Trading flow, so its logistics, trade
  // transaction, customs clearance and any claims should be reachable from
  // here rather than by searching each module in turn.
  detailExtra: (r) => (
    <>
      <ShipmentDocumentsChecklist shipment={r} />
      <LinkedRecords
        heading={`Chain for ${String(r.shipment_number ?? '')}`}
        links={[
          { title: 'Deal', resource: '/trading/deals', matchField: 'deal_number', matchValue: String(r.deal_number ?? ''), hash: TRADING_HASH.deal, codeField: 'deal_number', subField: 'deal_name' },
          { title: 'Logistics', resource: '/trading/logistics', matchField: 'shipment_number', matchValue: String(r.shipment_number ?? ''), hash: TRADING_HASH.logistics, codeField: 'logistics_number', subField: 'status', emptyLabel: 'No logistics movement recorded for this shipment yet.' },
          { title: 'Import / export', resource: '/trading/import-export', matchField: 'shipment_number', matchValue: String(r.shipment_number ?? ''), hash: TRADING_HASH.importExport, codeField: 'transaction_number', subField: 'status', emptyLabel: 'No import/export transaction for this shipment yet.' },
          { title: 'Customs', resource: '/trading/customs', matchField: 'shipment_number', matchValue: String(r.shipment_number ?? ''), hash: TRADING_HASH.customs, codeField: 'customs_reference', subField: 'clearance_status', emptyLabel: 'No customs declaration for this shipment yet.' },
          { title: 'Claims', resource: '/trading/claims', matchField: 'shipment_number', matchValue: String(r.shipment_number ?? ''), hash: TRADING_HASH.claims, codeField: 'claim_number', subField: 'status', emptyLabel: 'No claims raised against this shipment.' },
        ]}
      />
    </>
  ),
};

export function TradingShipmentPage() {
  const [sendFor, setSendFor] = useState<Record<string, unknown> | null>(null);
  useEffect(() => {
    const onOpen = (e: Event) => setSendFor((e as CustomEvent<Record<string, unknown>>).detail);
    window.addEventListener(SEND_SHIPMENT_DOCS_EVENT, onOpen);
    return () => window.removeEventListener(SEND_SHIPMENT_DOCS_EVENT, onOpen);
  }, []);
  return (
    <>
      <TradingMasterPage config={config} />
      {sendFor && <SendShipmentDocumentsButton key={String(sendFor.id)} shipment={sendFor} autoOpen onClose={() => setSendFor(null)} />}
    </>
  );
}